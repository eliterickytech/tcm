<ul>
    <a href="<?php echo "https://thechefmelo.com/collections-list.php?token=".$access_token_seting . "&v=".$time;?>">
        <li>MANAGE COLLECTIONS</li>
    </a>
    <a href="<?php echo "https://thechefmelo.com/send_delights.php?token=".$access_token_seting . "&v=".$time;?>">
        <li>SEND DELIGHTS</li>
    </a>
    <a href="<?php echo "https://thechefmelo.com/banner-manager.php?token=".$access_token_seting . "&v=".$time;?>">
        <li>MANAGE BANNERS</li>
    </a>
    <a target="_self" href="<?php echo "https://thechefmelo.com/profile.php?token=".$access_token_seting . "&v=".$time;?>">
        <li>Permissions</li>
    </a>
    <a href="#">
        <li>Support</li>
    </a>
</ul>