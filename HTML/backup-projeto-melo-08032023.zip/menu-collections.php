<a href="<?php echo "https://thechefmelo.com/collections-insert.php?token=".$access_token_seting . "&v=".$time;?>">
    <div class="icons_collectibles">
        <div class="area_icons_collectibles">
            <img src="img/collectibles.png" alt="">
            <h2>+</h2>
        </div>
        <div class="title_icons_collectibles">
            <p>add collection</p>
        </div>
    </div>
</a>
<div class="icons_connections">
    <a href="<?php echo "https://thechefmelo.com/collections-delete.php?token=".$access_token_seting . "&v=".$time;?>">
        <div class="area_icons_connections">
            <img src="img/delete_collection.png" alt="">
            <h2>-</h2>
        </div>
        <div class="title_icons_connections">
            <p>delete collection</p>
        </div>
    </a>
</div>
<a href="<?php echo "https://thechefmelo.com/send_delights.php?token=".$access_token_seting . "&collection_hash=".$collection_hash."&v=".$time;?>">
    <div class="icons_chats">
        <div class="area_icons_chats">
            <img src="img/send_delights.png" alt="">
            <h2>></h2>
        </div>
        <div class="title_icons_chats">
            <p>send delights</p>
        </div>
    </div>
</a>