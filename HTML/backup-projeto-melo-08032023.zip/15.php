<!DOCTYPE html>

<html>

  <head>

    <meta charset="utf-8" />

    <meta name="viewport" content="initial-scale=1, width=device-width" />



    <link rel="stylesheet" href="./15.css" />

    <link rel="stylesheet" href="./15_b.css" />

    <link

      rel="stylesheet"

      href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap"

    />

  </head>

  <body>

    <div class="profile-new-delight-2">

      <div class="profile-new-delight-2-child"></div>

      <div class="profile-new-delight-2-item"></div>

      <img class="menu-icon" alt="" src="https://d1xzdqg8s8ggsr.cloudfront.net/63a9da2f504c63b433038b15/951fb52a-9bc4-4791-886c-132abe33ce47_1672075832675005279?Expires=-62135596800&Signature=Wvrpw9grIn1e4PiHmWsd7TemUeg1CVCRd1DbKdonvhTEW9F2nAcWHsBeqFtb8iAA2tSOpvcPmlwbdIczv086Hw0hqlKnlVvmrb64KZQ7BeuMMeK9mg3m-51L-VdZVHL0RpE96sdsyNVHPO6fwbwnyQJ3C5NlMjHk0z1JAhDcVMaFR2ZkH1-MecnB1uXLapQ34RhiKKUl2PYTlRCol3iDaNi9xZTVKPZCndBAJO-udQX6-sTlVmKEJmTblmUiWF4Be1oMx-iXy3QI1SbP08QeBEXimHQL3PSPWrPcrjf1VgGyMeZFWN954YFC3uDUhGHlAoPIdmDCYJ6mekZ7771JdA__&Key-Pair-Id=K1P54FZWCHCL6J" />

      <div class="a-delightful-christmas">A delightful Christmas</div>

      <div class="hello-michael-hamilton">Hello, michael_hamilton</div>

      <img class="edit-icon" alt="" src="https://d1xzdqg8s8ggsr.cloudfront.net/63a9da2f504c63b433038b15/4706590a-74ea-4913-8a06-6eb6d35da633_1672075832675094754?Expires=-62135596800&Signature=d5Z2uhtJ4IeF0W8kBVg4R3JjtdES24IPjXhlLQF0bh9u6q6TuinwWxTatINI~fFzNalKzzIrebClNYn7w85k1SJ5-ESoaAM~2SwhA4V~f2HyqGsaQ2urXqis58B6JoR34r89kJMLBt5IEfz1Gj2st27oF6CB-nipt3H67bHhdcGTg5tefbriPjIDcIMm56C6CGo53rId1LMXrTavkO8CYV8HPDBNlhCp0kIsIeK7yhU1totV0MczaPr5uj6qDzX26IXBYh5f5fzZGaE-UNO8~OutLzaFsznnwLNVCSrlhCqhFu9Rqyt9KmUIdoGag9yqeNCNAsy5c4zzgi9ew3RBuQ__&Key-Pair-Id=K1P54FZWCHCL6J" />

      <div class="page-1-v"><span>Page 1 </span><span class="v">v</span></div>

      <div class="my-collectibles-delights">My collectibles delights</div>

      <div class="collectionables">collectionables</div>

      <div class="connections">connections</div>

      <div class="discussions">discussions</div>

      <div class="parent">

        <div class="div">4</div>

        <img class="group-child" alt="" src="https://d1xzdqg8s8ggsr.cloudfront.net/63a9da2f504c63b433038b15/026449be-2490-46bc-ae74-e5e3b5f76c6c_1672075832673640638?Expires=-62135596800&Signature=YUTWBUII-OV6fGhuRnRmSpnmTRygtQ-FaclxRpFijSuHpQi9303ZtxUe9fP4Uz2Vt7xJlziqMMCvVK9k89gbhkm8tVNNuUruFNkzV~UwYs1cmCbWOCD9UrO07TYD7-ZqN3judI-YvUItaHppEAiU0Ihl9QHgOHn8XHqUfwGYouIzPrQ2xKrO8HY6YWbeVxvFMXZ1gkBwtIkN~w-duoezGjwc76byBpjQVe219DoLAH5ppIsUVlSlxhiFoyFJTbfsWkCtArq5HLRBJKw9iwPZo1XNpX0KYXSLJiqsii3oC4apaDQ77VPb-X6QmiOyPfCkoJhDJ2enX1JY7Pcbim7qmQ__&Key-Pair-Id=K1P54FZWCHCL6J" />

      </div>

      <div class="group">

        <div class="div1">11</div>

        <img class="group-item" alt="" src="https://d1xzdqg8s8ggsr.cloudfront.net/63a9da2f504c63b433038b15/429ea518-3525-4343-82a5-053eb4b21bde_1672075832673826342?Expires=-62135596800&Signature=HVLIO2aJPZZrbq3vaLhFwEe1ews~6petbB8ZLDOcg4X6RLuvhyv7pGvVCJYq6tFe3em3fAMKtzeEMkWlfR2YSccxC1ezd9ClBq--2LFM0XIwocBswl9luFAQrELFLQFJ-itpmcdhu8cHt5T6ziyQrKPhqoIdAErPIJF9LikX3C6cRf4EkMXmEZIRVYOoMrijgncL51F8QI6TUchP2e3-dHZls9Zj~ZwsPsZL7jCHh7lFsJk9ujpBEjQCPXBtfVFIFl38hRZcEIbyttAEFc6i1Zv5gubpEotPwkveeLszYELLurzjff-RI7BKNLcI4IKFyrti8PV9IKfYFh50xFdfrA__&Key-Pair-Id=K1P54FZWCHCL6J" />

      </div>

      <div class="container">

        <div class="div2">2</div>

        <img class="group-inner" alt="" src="https://d1xzdqg8s8ggsr.cloudfront.net/63a9da2f504c63b433038b15/5881117b-f68d-4aae-a6f6-c110829cc6b1_1672075832673927205?Expires=-62135596800&Signature=IqPRZpJhx3dukdhBP-ncbXdIeb6SWLTkBEpB~ZsdCZI-ZFAqBv2RAQ0zCs8USYaIwgp-2dKuxBASXVsd5srqExQcNHVPBD124x3uB9VywGS8ayxSPReeTp7jRC~6PC~-EyTY~CzKo0Tkb7~Yswdmf5pCtd7kxIY-oCMqbHfO1j1lXfWiqbtfVHBnIwMTeXUAgpSIyFiGr7L-ApljORcHcB-muTTJZGDwVrA1Kow-p2NQgNqbXkOC6wsMBQ8BLWzF9Ec-XBQN2f-PrIgeUOKMUbUvxJrDGr4R00zopDRTvDJpESABKEUrS8xDttYpxLTTatn7lltuQQpYFesIfr3isw__&Key-Pair-Id=K1P54FZWCHCL6J" />

      </div>

      <img

        class="profile-new-delight-2-inner"

        alt=""

        src="https://d1xzdqg8s8ggsr.cloudfront.net/63a9da2f504c63b433038b15/5bf49aec-d6bb-43ec-8254-b91f8790c7c4_1672075832674019832?Expires=-62135596800&Signature=ChVXuZN9qDl151-KQ13HHIDHe0RqkHy3ACqMB4YbZiBaFc8Mtla27SuV63dhUhcdjYNYA~h4f5w7g3DiKKAIMgzlI6M2qX1VF8001a2LwT9Hta1rW3Qx61NK4HLQ2jNWENUyWJezqHy25XXelC2CVncAUxO0nxtKjAmain4yLPBPCEUALisqw~diNIQlgOzMY0PqzWN4XT2jyIo96PuW1ci9z~T9jg8VMWBWHcp0R62Fij8c7-WrcxvtRolyEjiFDB3oHI0TPZKvcXSwyPuV1Z8v1PM-kLOXDvfBszdsrw8mjS78ZTWDS5172iuKbPyktB09Dcuaw7dzAqTExda0uw__&Key-Pair-Id=K1P54FZWCHCL6J"

      /><img

        class="rectangle-icon"

        alt=""

        src="https://d1xzdqg8s8ggsr.cloudfront.net/63a9da2f504c63b433038b15/91b56eaf-2fce-432c-8eb2-5180b520668f_1672075832674106774?Expires=-62135596800&Signature=b2WNDOYqxEvVG3OTNRojw7B5qvtuOUeJ4JUnkc3xyTZCYXtrZ5tHIiLnVnpJS7~KMo7cdDda06f7eOcBhza8kaA2pEgx5ZUpKw3Wvlx2rCMtspblNwZAG8pVwI~8nC8jiepr-z2qyR3wwsdiDIcqFciN5vALR-GxyiLMm4Te39W4wJFKmEZ1FYSHHBXdUxDdBjLGSaht~UMa3WCyj40qjxjpeWBR9nfxnwnfwhg1GhLXIk0732PVSlGNivU2wmPuRdrjxLnZRugXj7fEEYGOtlYJzuGdtkZWk-2Cbycr3LxsefRv5TBF2PlA7HnaFPhd1v~LlgbAhBdNlR27xI7QYA__&Key-Pair-Id=K1P54FZWCHCL6J"

      /><img

        class="profile-new-delight-2-child1"

        alt=""

        src="https://d1xzdqg8s8ggsr.cloudfront.net/63a9da2f504c63b433038b15/dffd5c07-14fc-4ea6-ac7e-25e89de929da_1672075832674195369?Expires=-62135596800&Signature=m771aAzxoFXGs8iyuOU2PgxbJTJ1xIlCKLxYdo5k1kltpdkAUackfBG3aESNyQBx4jiiS6vNAXo72rrfJTDE1xVzupZa0u0VNYU3PtVl1uG9zSOAjmftbZh43vfUIlOywpdDPqOmOwBTd~ZH0akN5EaK-57SF3e~k32DmB1-XeCKXkzmxNMjfrD86Um7BF6MOAdYtQtWW2ePTVIz6hreW09fRAiX3p1bJzPMdk7xNcsXlpqIKNBraByJHEoXjV8XeIICG2HAGMCNXLKtGdKCSJZTSdIFsKVldgO0t99Bop2o2X2U187NbQoqzffuz75gyJEo7mIBuupo3axqPZ1IaQ__&Key-Pair-Id=K1P54FZWCHCL6J"

      /><img

        class="profile-new-delight-2-child2"

        alt=""

        src="https://d1xzdqg8s8ggsr.cloudfront.net/63a9da2f504c63b433038b15/5016214d-521c-456c-899f-812aa5ade823_1672075832674369049?Expires=-62135596800&Signature=lwcvLBgBPF0uagCAlpvlxkuoOQ53OZ0DdcHrArvqHMGSFVb7p83QmVxtGpJfvZDrC7CJdAP1USx2VXiFx81BEOEKVdS3EpZW7mRonyzoz6onD3HBOvOHvzjaT3qMEdIyeTIRFePT9~ChlyOTLoXfMVdHkv3O9A0DBUWDiovme5Lppf6hNHF~J9pZ9BvDF6T-Vho3ltLN1p4nVfixFMp0w3eDpUluLh4mJxMUbFfG0hP7F5CeKpTMbHF7faCER~Lh4keBhYYMb7To5q-jy4fXZyx~IG5b12hZsneHT3FztOb6VdNOGGwt2wIhfadVe4KO~-uLK-ragBUj2I6esl2QHQ__&Key-Pair-Id=K1P54FZWCHCL6J"

      /><img

        class="profile-new-delight-2-child3"

        alt=""

        src="https://d1xzdqg8s8ggsr.cloudfront.net/63a9da2f504c63b433038b15/ab89d71a-32f8-4f30-8d83-af12affd012f_1672075832674453969?Expires=-62135596800&Signature=loql7L6fdu5iKGUbovcFQgrpmEZIf8DYwix2Vc2PxTQhJ2wFs0V~aKhg6ibrC9sJ3gMG5F~zJ2WOcM54JIO-X5mZvchvjcQkguRydPKdoch~hU0OvuImDXxB2c2EwND~vfTKDZYGlb0OUmGPwjKpO85t6py3FqoD-eNkZn7hfNrarYJDzEQNaFlcDnWfnSaTK98y91jTVXMEfQLKb6OG07zIKk4rfGgPmjr9yQ7HQbvPhUu1WVZk3wvXy2wC9hJPqTsBQSdpKX7Uv93SwIwOkuWPc5EyZXjxXege7wZISEDAm9oOCk2mypqr0oRKjWORAAcpsLlY-pF6jaBVshzvAQ__&Key-Pair-Id=K1P54FZWCHCL6J"

      /><img

        class="profile-new-delight-2-child4"

        alt=""

        src="https://d1xzdqg8s8ggsr.cloudfront.net/63a9da2f504c63b433038b15/93677793-eed9-443d-9d2e-032e98ff51ea_1672075832674544639?Expires=-62135596800&Signature=hmdPdDVYIl2JoBX6deODI~1b-FeU3yeITPR7-7Qg60tM--lGFncX1trAkTvKY1dbvbzHkcnyoKXCjB69awuIuvE1P-4-48qLxBTaagnW~QPdCaS~JTIrztMgsMlXblZE8Oj4pHdOsTtBEZV8GHsxOYcmEihAbJ7dhpLDonF5FFmBdgnFcUYs7wMgzsu6ZTV1BnCcwFvRT7JOHUc1KgRJeSHgvL2eiQt7FjqEgdKS99WCVRzjb3GxHfUu86JERXZOXJUbvaNHYdrQHyW4IYBVULO-C54NblXBMGLMW9useSWMkepjAALlRuORbh~GJfzZ1Yntw1kyrIGkhqCtFtik~A__&Key-Pair-Id=K1P54FZWCHCL6J"

      /><img

        class="profile-new-delight-2-child5"

        alt=""

        src="https://d1xzdqg8s8ggsr.cloudfront.net/63a9da2f504c63b433038b15/b4dcd8e6-ac55-496b-bea9-2081dc7d0c3e_1672075832674631255?Expires=-62135596800&Signature=EFkxVmmwed5kp74jBUZmi5AKbCPxsJhYvrQW3qsmcS6Gk0ezXeWbAaJMEhuzt9FYbpv8G8XcyHrraVUE-mmNqYUNajb4QvgRz9L2Rq8Jyqc-J5jd5lS1X62jF0uW-b53STbzCDN1~rNCenAp8cO32~77f1SA2JZSe8N3mp4OzNrI2otu1qFPykoS223AUXqMYJ1PCeUyiP5fEkXXo4RWqwBvmcv8QsN22oTE4wZAvDJQPi~Q~wIpVOlYkovnlrqaVATe2G0Uq8B4RLij3RHxBXQdfsXGjroSWZQjQu42SVvR8CYRv6ATD1EREOadtslS~gAV2pyA5MToVBuyjLKNJQ__&Key-Pair-Id=K1P54FZWCHCL6J"

      /><img

        class="profile-new-delight-2-child6"

        alt=""

        src="https://d1xzdqg8s8ggsr.cloudfront.net/63a9da2f504c63b433038b15/bb0e1291-909c-4705-aa44-c68ff2061212_1672075832674735594?Expires=-62135596800&Signature=rQqqoGivktxTGVdCl2fkpcfVNjvrSkmXALrc-5mu2gyjRPmlEa7K6edueNnrq8sRLna8QNTpaKfDmjGb12Yv0KscwSju3jLrDpShVAVPI5Tpmwv1ifmOiAwOkltDcRap5ae3F1~0PHlkO2cGXbOkkxwjkH1C46RXV3TGAMniJzg-olFsjGQsGesSnSHg8oWBFk6-8HhlBUCsvQI46uCD~vY7R2Pn-b219MZ6vCk6Iyyxk1EIkMPZ6Km9tm-uV9Wdafp81~x1qdwmBOvcL69NfJhs29AgUig9f7ijT6OhqkR2SkQfgxtbqZ0pIrzMCBrN~pKn18X6C8CAhKN6DANFlQ__&Key-Pair-Id=K1P54FZWCHCL6J"

      />

      <div class="rectangle-div"></div>

      <img

        class="profile-new-delight-2-child7"

        alt=""

        src="https://d1xzdqg8s8ggsr.cloudfront.net/63b448600bb6367e228e9181/7fa78d46-aecc-478e-b2d7-9f05e67edfb6_1672759399708340394?Expires=-62135596800&Signature=tIRahAmybUM6k8QN1lQnZ7aPSHzT-IvLR5oJH5poIN7CbGIr5Cmj4MGbRR9sBNPNO6vgP4pW96D09nCj0gpxx7eyyGj5Upl0aXEHY8WGSUmDuG0zCjJkvAAN04OFr5Uq2LPHzUDFoQg2sgv7sBi3kLC5DCnTYahkdmZ~t72Wq2b2ChO17st7IOXXvHet9yUuldBHrZsSLooklqR4L-3xJBLr2HJSXqIsLahT1BQ2UL9vrbyx29OucDv7hKlW5SwnA8JJA4PKIKeychwbHMdCmTCH5VUe0rLzbJptowYSg7d85QTh6DfyR0w68UlrG-gsL~SeRGdE3eboFN1dnVVz3w__&Key-Pair-Id=K1P54FZWCHCL6J"

      />

      <div class="melopassion-dessert">MeloPassion Dessert</div>

      <div class="dessert-is-an-opportunity-to-m">

        Dessert is an opportunity to make something beautiful as well as

        delicious. This is the process of the preparation of our most passionate

        piece: layers of chocolate sponge cake, passion fruit cream and special

        chocolate for a mouthwatering experience.

      </div>

      <div class="fixed-itens-bg-superior"></div>

      <div

      form id="search" class="search-bar">

        <div class="barra-de-pesquisa"></div>

        <input type="text" id="search-bar" class="search-bar" placeholder="Search">

        <a href="#"></a>

      </form> 

    </div>

      <img class="icon-side-menu" alt="" src="https://d1xzdqg8s8ggsr.cloudfront.net/63a9da2f504c63b433038b15/acd12495-636a-40ed-9a7f-7470f829a7e8_1672075832675261688?Expires=-62135596800&Signature=PzYVdFOywWC1scki4dWD9Gct6haL3im9zyQah~Mg6D6-F3J68RRnacZNSw26Rkx27NjbHoo394kqOrScGjhgHfVI~Bl~cKlYY00pEskrwmZZojC3VPs14sNlcKz~pbZFXrz3oAfpWlzlfjxXgpemZsyr75q~KftQvYWTN3bDnSMJV-EguJs0~p7mR~raEA57NV09pq~2aJlZj0pf~GG5x75bdUpSE0~udC~6JmspDEzGRSizhLMgDm34Gnxzcax~R1StzzQh3wsxg6Xvb7548iU0rfgmNC3K8pxc8cBwZ9yiYpmKRdScMTat-B1~kcIREG8-g~bDLm9~exSX1UXESA__&Key-Pair-Id=K1P54FZWCHCL6J" />

      <div class="menu-inferior"></div>

      <div class="icon-home-in-parent">

        <img id="home" class="icon-home-in" alt="" src="https://d1xzdqg8s8ggsr.cloudfront.net/63a9da2f504c63b433038b15/dfa2efd2-9357-4ad4-8931-75d59046692d_1672075832675352353?Expires=-62135596800&Signature=lab11jkKQUXJ00vfOs3jwE6GmxbwDfGakhjuxzhMTmj7SZ51e6qzs-SHLZF3mpxoLvHSs3WtVXffzsmkDSPWuuOy63b65LyXKD8BzlmgtcesRNZeq1aLeFCnKreeH7DEH7nSl5aBRGCfEAduZjAbncXrnetDtPMbR1HmMq1zgoEDov2NqOtEL2CQi7GsM3pEjjm6yWkCQGmO5CI5WzvZTl0u9sUl9~JZ0ZEBxhFpzTzP5f9AWanTSsDtE0kDTIUSXQ4y6YCLoWgqeuUGPWzMJIn9DIolVDXk8pAowVtdkO8SzVrZHGbpgRA1n3xTQHtFtpF2uD57~5roadYbZ4-quA__&Key-Pair-Id=K1P54FZWCHCL6J" />

        <div class="home">Home</div>

      </div>

      <div class="profile">

        <img id="pvdu"

          class="icon-profile-out"

          alt=""

          src="https://d1xzdqg8s8ggsr.cloudfront.net/63a9da2f504c63b433038b15/5d417579-78d3-4965-9d05-4be8d4a40d59_1672075832675436880?Expires=-62135596800&Signature=mldvo5LubgEoTyinqinnHRYUVfD4o3xBsQh6KyVv5ZC1J-n8BYGDgokpbsbd7VBAuoN5j5fiAQJGdFa9RQ5jkCyVAWEOghqDMOoE5O57fGAwIIVWqRh76zfW03errAXJomykwMVUUytN16~fDnJhwUH1TvPcR-AKi1QBB--stwonVQFoihw9NwKyFv8r6uZ83snukYvbLHekMqHyYz6rCUKvleK3pg4qcpjLb59x2dWolCir-FkctJYpDTGMKWfTuv6mYBmXBvmnDrkCeVmV2pj6~-s-OamAVNkIBUIXMN1iDHm4LnS7WXEGjgxVXEmKDIfX56a905GWVhpcLZaS7Q__&Key-Pair-Id=K1P54FZWCHCL6J"

        />

        <div class="profile1">Profile</div>

      </div>

      <div class="profile2">

        <img id="usuarioc"

          class="icon-profile-out1"

          alt=""

          src="https://d1xzdqg8s8ggsr.cloudfront.net/63a9da2f504c63b433038b15/a7479abd-35c6-4c44-bba1-0297db2755d3_1672075832675524632?Expires=-62135596800&Signature=HF16UOUAW-PQMCGaM9iajWj8ptrpx2TzRk5u7gn3s25JJmpWe7m-g4ZmEGSHk3gHHDJWjPE1UM65PdRhxPquvBbmOooqhQhQcCpm8LGAVm70kHnk3C3Hkteky7C6OVvVEa2YjP8uFnAsXfvJ~AdYL9TpxXm~1LJcc75y01TpgXeql9TPMJUcsc-4K1~YxLqQG3Dsr5B6Y68A593tS2zFq3eXyIyxOYdqXu3sV2lw5s1dhl8eaBIqDYaQMiFLpsBmwjNNciJw6-3pIfTY94N00UJJ0s1ce3dE8t898ozfe8fK8BAV~ifk00LJLn93qzEV7htNWGsGgC~w~EQZAgkknQ__&Key-Pair-Id=K1P54FZWCHCL6J"

        />

        <div class="home">Community</div>

      </div>

      <div class="rectangle-parent">

        <img class="group-child1" alt="" src="https://d1xzdqg8s8ggsr.cloudfront.net/63a9da2f504c63b433038b15/6a31c6f3-dc26-496d-a9b7-c7bfb6f0f4d7_1672075832675610179?Expires=-62135596800&Signature=n9VPjOOdP6MjqRB4LRpxQ1Fv9yELd2aGMsyC7sROpb2UVR7lTaS6Zr2yKxSGyIrJxM63DQAF2VZOUaNo5BaMaRiSIbbq4y~UljfaI~Kpf-F7tNxkCC6zYch9F5qpOd7LcVLu5rp8XNX9xqBdHGcXodwScxLxWQcswjgUOE2GBM5q0Q3LN7A09JFHsa90TY~QKZt-UNoystWbum3KfC1ZExuNAl4jtfcE94jIvHpQDvoM0-siHzFskDvGTCU0CabqCGo8qZokk-RL2u3P9hiWWHsU7WyHLMNFGM5QQTU7Z1F-O0jZdVD2vBMoadL-O~BYptfMsS~SsyTyaEF7-Hb4wg__&Key-Pair-Id=K1P54FZWCHCL6J" />

        <div class="my-collectibles">My Collectibles</div>

      </div>

    </div>

    <script>    

      var usuarioc = document.getElementById("usuarioc");

      if (usuarioc) {

        usuarioc.addEventListener("click", function () {

          window.open("usuarioc.html");

        });

      }

      var pvdu = document.getElementById("pvdu");

      if (pvdu) {

        pvdu.addEventListener("click", function () {

          window.open("pvdu.html");

        });

      }

      var home = document.getElementById("home");

      if (home) {

        home.addEventListener("click", function () {

          window.open("pvdu.html");

        });

      }

      </script>

  </body>

  </body>

</html>

