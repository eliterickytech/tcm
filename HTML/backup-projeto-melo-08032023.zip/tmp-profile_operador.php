<?php
//####################################################
//####################################################
//####################################################
//Projeto Contratado Via Workana
//Desenvolvedor Giovanni Barbosa
//https://www.workana.com/freelancer/8f1f0c0f1e3374c5aecbd8edb6a19a06
//#####################################################
//#####################################################
//#####################################################
require_once("header.php");
//####################################
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no">
    <title>Profile operador</title>
    <link rel="stylesheet" href="css/style.css?<?php echo $time;?>">
    <link rel="stylesheet" href="css/bootstrap.min.css?<?php echo $time;?>">
</head>

<body>

    <section id="container_home">


        <div class="container_home">
            <div class="container_home_int">
                <div class="area_home">

                    <div class="menu_header">
                        <div class="icon_menu">
                            <nav class="nav">
                                <input type="checkbox" class="checkbox" id="checkbox">
                                <label for="checkbox" class="label_menu">
                                    <span class="menu_hamburguer"></span>
                                </label>

                                <div class="container_menu home">
                                    <div class="container_menu_int">

                                        <div class="area_menu">
                                            <div class="logo_menu">
                                                <img width="100px" height="100px" src="img/Logo.png" alt="Patisserie">
                                            </div>
                                            <div class="social_icons">
                                                <img src="img/instagram.png" alt="">
                                                <img src="img/facebook.png" alt="">
                                                <img src="img/world.png" alt="">

                                            </div>

                                            <div class="admin">
                                                <h2>admin console</h2>
                                            </div>

                                            <nav>
                                                <ul>
                                                    <a href="#">
                                                        <li>MANAGE COLLECTIONS</li>
                                                    </a>
                                                    <a href="#">
                                                        <li>SEND DELIGHTS</li>
                                                    </a>
                                                    <li>MANAGE BANNERS</li>
                                                    <a href="#">
                                                        <li>configurations</li>
                                                    </a>
                                                    <li>Permissions</li>
                                                    <a href="#">
                                                        <li>Support</li>
                                                    </a>
                                                </ul>
                                            </nav>

                                        </div>

                                    </div>
                                    <footer>
                                        <div class="collectibles">
                                            <img width="20px" height="20px" src="img/logo_collectibles.png" alt="">
                                            <h2>My Collectibles</h2>
                                        </div>
                                    </footer>
                                </div>

                            </nav>
                        </div>

                        <div class="logo_home">
                            <img width="30px" height="30px" src="img/logo_small.png" alt="Patisserie">
                            <div class="collectibles_home">
                                <h2 style="font-weight: bold">My Collectibles</h2>
                            </div>
                        </div>

                    </div>


                    <form action="#" method="POST">
                        <div class="area_form">
                            <input type="text" name="search" class="search" placeholder="Search">
                            <img class="icon_search" src="img/Icon_Search.png" alt="">
                        </div>
                    </form>


                    <div class="area_profile_operador">
                        <div class="area_profile_int_operador">

                            <div class="profile_operador_admin">
                                <div class="title_profile_operador">
                                    <img width="30px" height="30px" src="img/profile.png" alt="">
                                    <div class="texts_profile_operador">
                                        <h2>Chef_melo</h2>
                                        <p>10 collections available.</p>
                                    </div>
                                </div>

                                <div class="operador_admin">
                                    <h2>admin view</h2>
                                </div>
                            </div>



                            <div class="icons_profile_operador">

                                <div class="icons_collectibles">
                                    <div class="area_icons_collectibles">
                                        <img src="img/collectibles.png" alt="">
                                        <h2>+</h2>
                                    </div>

                                    <div class="title_icons_collectibles">
                                        <p>add collection</p>
                                    </div>
                                </div>

                                <div class="icons_connections">
                                    <div class="area_icons_connections">
                                        <img src="img/delete_collection.png" alt="">
                                        <h2>-</h2>
                                    </div>

                                    <div class="title_icons_connections">
                                        <p>delete collection</p>
                                    </div>
                                </div>

                                <div class="icons_chats">
                                    <div class="area_icons_chats">
                                        <img src="img/send_delights.png" alt="">
                                        <h2>></h2>
                                    </div>

                                    <div class="title_icons_chats">
                                        <p>send delights</p>
                                    </div>
                                </div>

                                <div class="icons_chats">
                                    <div class="area_icons_chats">
                                        <img src="img/chats.png" alt="">
                                        <h2>+</h2>
                                    </div>

                                    <div class="title_icons_chats">
                                        <p>share message</p>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>


                    <div class="bar"></div>


                    <div class="area_grid_collectible">
                        <div class="area_grid_collectible_int">

                            <div class="area_texts_collectible">

                                <div class="title_collectible">
                                    <h2>Collections</h2>
                                </div>

                                <div class="page_collectible">
                                    <p>Page 1</p>
                                    <img src="img/arrow_down.png" alt="">
                                </div>

                            </div>

                            <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                                <ol class="carousel-indicators">
                                    <li data-target="#carouselExampleControls" data-slide-to="0" class="active"></li>
                                    <li data-target="#carouselExampleControls" data-slide-to="1"></li>
                                    <li data-target="#carouselExampleControls" data-slide-to="2"></li>
                                  </ol>
                                <div class="carousel-inner">

                                    <div class="carousel-item active">
                                        <div class="row">
                                            <img src="img/profile_part_1.png" alt="...">
                                        </div>
                                    </div>
                        
                                    <div class="carousel-item">
                                        <div class="row">
                                            <img src="img/profile_part_1.png" alt="...">
                                        </div>
                                    </div>

                                    <div class="carousel-item">
                                        <div class="row">
                                            <img src="img/profile_part_1.png" alt="...">
                                        </div>
                                    </div>

                                </div>
                                
                                <div class="text_delightful">
                                    <h2>A delightful Christmas</h2>
                                </div>
                               
                            </div>
                        </div>
                    </div>


                    <div class="menu_footer">
                        <div class="menu_footer_int">

                            <div class="area_menu_footer">
                                <a href="profile_prototipo.html">
                                    <div class="menu_f">
                                        <img width="27px" height="28px" src="img/Icon-Profile-In.png" alt="">
                                        <h2>Profile</h2>
                                    </div>
                                </a>
                                <a href="home_usuario.html">
                                    <div class="menu_f">
                                        <img width="27px" height="28px" src="img/Icon-Home-Out.png" alt="">
                                        <h2><b>Home</b></h2>
                                    </div>
                                </a>
                                <a href="#">
                                    <div class="menu_f">
                                        <img width="27px" height="28px" src="img/Icon_community.png" alt="">
                                        <h2>Community</h2>
                                    </div>
                                </a>
                            </div>
                        </div>

                    </div>

                </div>


            </div>
        </div>


    </section>

    <script src="js/jquery-3.6.1.min.js?<?php echo $time;?>"></script>
    <script src="js/bootstrap.min.js?<?php echo $time;?>"></script>

    
    <script type="text/javascript">
        $('.carousel').carousel({
            interval: 5000
        });
    </script>

</body>

</html>