<ul>
    <a target="_self" href="<?php echo "https://thechefmelo.com/my_profile.php?token=".$access_token_seting . "&v=".$time;?>">
        <li>Permissions</li>
    </a>
    <a href="#">
        <li>Support</li>
    </a>
</ul>