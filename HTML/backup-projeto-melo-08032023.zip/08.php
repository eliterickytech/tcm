<!DOCTYPE html>

<html>

  <head>

    <meta charset="utf-8" />

    <meta name="viewport" content="initial-scale=1, width=device-width" />



    <link rel="stylesheet" href="./08.css" />

    <link rel="stylesheet" href="./08_b.css" />

    <link

      rel="stylesheet"

      href="https://fonts.googleapis.com/css2?family=Inter:wght@400&display=swap"

    />

  </head>

  <body>

    <nav>

    <div class="menu-operador">

      <img

        class="logo-icon"

        alt=""

        src="https://d1xzdqg8s8ggsr.cloudfront.net/63acf6be33a79ad2d31d7828/86b50d8e-92a3-409e-8504-7f0a0fc4d9f2_1672279749291561854?Expires=-62135596800&Signature=mb8W3CXn1PFtDQtk0TUMFMbrB~zKu-jT-kuNtLc1GNnnRuG~dcJhtyH1RlGeJ6lLXs~iFOeL7MplBRQv8kp3JnPXZNJvpgRUMBuvxZoXPkfETPeKHHQwqiUDqOiwK11ZO1LID1kkK~NVbZZ6zI5lGRpOMsjEdVKs~K5xp-94HTqCICDLf1pJR4gKgViHSDP5hLbWrmw7DORp3kgtvMJluQdkbtAX5B153-P5LpMnozZYLtekXRBvO-dUsbPYlSTXYtXDk9skUfewTHvyIBJRTw0k5dJEya6UZz9EgnQ6xrgFaVVD4Chjss~mh-z9aSGXpsWyTAUnNKpPSt28YPb7Xw__&Key-Pair-Id=K1P54FZWCHCL6Jpublic/logo@2x.png"

        id="logoImage"

      /><img class="close-icon" alt="" src="public/close@2x.png" />

      <div class="my-collectibles-parent">

        <div class="my-collectibles">My Collectibles</div>

        <img class="logo-icon1" alt="" src="https://d1xzdqg8s8ggsr.cloudfront.net/63acf6be33a79ad2d31d7828/91af49c1-cf9a-4390-9a16-1fb1c886cf5c_1672279749291852342?Expires=-62135596800&Signature=QG-4L~74-pt~x8hBF~qCXQEVhGhOHzD0naOOiZpuvzqehTdfwkniL-QX2LIxZW33z2iXtZqhAYKGsWP2rf-Z-sIORVRrOVdLOzdjdmQaz5bgQP59lrQ2kx9zbfU6VCGpCLSkECpAhPkYA7SpSdRLHtt5ZxxkGCv~j-ygo-cEKZ3h-iTrbtRlZsiPTXyvmHbAiSSf5VPHI61AagQh2CZIaZm0K0Y3iur5lWnthCohZIBLYYLkiYs9KhQwRDIDQuGpNSoz45DHe0nsBbbiJzhQb-O3d~PPKs7kBbhLZBRXe0tqkeeWN5oNhIyPprPtfAB5k2yrKlX7DDlzAUQ2zh5N3g__&Key-Pair-Id=K1P54FZWCHCL6J" />

      </div>

      <img

        class="menu-operador-child"

        alt=""

        src="https://d1xzdqg8s8ggsr.cloudfront.net/63acf6be33a79ad2d31d7828/47518fc7-318c-4bab-817d-f37878770b35_1672279749291942221?Expires=-62135596800&Signature=j3t~LtsSqQFl1AhNoP3yBbmbg1BwJ7rdMt6BWW0o6g4P6HOS4olFeef-YyO9P2Od~lqkFcmP0fB7cTwffcRW7UsztB-Y7pNOaSwuJ2EmLuNOUzJGXwAa01~dkxPZWR1lSyWFZNIF8e6-19MgCVpwT6tLu9G1JTlWi-n5-Tvj~aPKlK~1wC9uBnJBXyLxFW95Q5nOuBfeD0bee80E2vo9c74a5vBe8uJiC8V9mJgwqydbBnnX1L5yFfleSGn6SHHhrm2qXySVEUt0FqVxot3w6by6QXfaK2wapfiVOL8UxL4fG-zi1pTIrePzbt6fTo5S8yOTCv6IQGGgIlx6vPbXZw__&Key-Pair-Id=K1P54FZWCHCL6J"

        id="rectangleIcon"

      /><img

        class="menu-operador-item"

        alt=""

        src="https://d1xzdqg8s8ggsr.cloudfront.net/63acf6be33a79ad2d31d7828/e5782f0a-397a-41f1-8b24-50511457f6fd_1672279749292030125?Expires=-62135596800&Signature=eqPhNrl-8w9ySx5ewUHW5~wYAqMmkTF3ik6KlM3od-sz2QGL7nyD~mRK~LA9-Oxu9a5jJecXerrL-cWN6dHie4gRKFraoTYPsBVWTce2Q3AhpdY63Ir8BTmd0j8YfU~kFZqUWjw~DmJyMISECNAqE55mKcYcYGZwOdOMd6-lTi9RS0NG9PBi49~JImOVtebpo9stZVbRL9K32glTe~G9KZFLIJCUyLWtZpHhuJ9XXCisjb4FqMJ8oWqGRiHp7gUXtpcd~KRMRuCbU-19Nbp-z9dEUSNiJlsO33NL2O3Zl9rQOVUfPs7NrZRnSc1mueJyt50XXuwaczGQsIHI0Fa-Tw__&Key-Pair-Id=K1P54FZWCHCL6J"

        id="rectangleIcon1"

      /><img

        class="menu-operador-inner"

        alt=""

        src="https://d1xzdqg8s8ggsr.cloudfront.net/63acf6be33a79ad2d31d7828/c9f5f346-9e6f-4c7d-bb94-a30214e583d7_1672279749292117246?Expires=-62135596800&Signature=v0ZPm3D0LzOLNPxrq8iz7NVUCEJeBFil0Ci~LiAYV8C2XtciYeo6QfZSvsIzkQn~N3R7u~tqKFAWK06ZLwMiHXxZ~WjVD3iVc12OdH89qmJtu2ChAHpRHoe1qRAwkG-iId9tkuM2eq6PrjJriSocZlMnjcP6Q49AeTYoAR8QuG9lrwwN4TZQxERkEKRuHBVLycg8kAIoffipoke9O5duulZ~5kFcefcE3q76iuqrEkFnHlcotdrp2-TRHY8QwEee7gBoQJre-rIdq9P5883nAmH~y3~tLzIvlgvb3HqrhTNbssZeb2k8nuFn3OqwBqx2yHordZQEgx8EbXCl6pnKvg__&Key-Pair-Id=K1P54FZWCHCL6J"

        id="rectangleIcon2"

      />

      <div class="rectangle-div"></div>

      <div class="manage-collections">MANAGE COLLECTIONS</div>

      <div class="admin-console">admin console</div>

      <div class="send-delights">SEND DELIGHTS</div>

      <div class="manage-banners">MANAGE BANNERS</div>

      <div class="configurations">configurations</div>

      <div class="permissions">Permissions</div>

      <div class="support">Support</div>

    </div>



    <script>

      var logoImage = document.getElementById("logoImage");

      if (logoImage) {

        logoImage.addEventListener("click", function () {

          window.open("https://melopatisserie.com/");

        });

      }

      

      var rectangleIcon = document.getElementById("rectangleIcon");

      if (rectangleIcon) {

        rectangleIcon.addEventListener("click", function () {

          window.open("https://www.instagram.com/melopatisserie/");

        });

      }

      

      var rectangleIcon1 = document.getElementById("rectangleIcon1");

      if (rectangleIcon1) {

        rectangleIcon1.addEventListener("click", function () {

          window.open("https://www.facebook.com/Melo-Patisserie-1038804902844311/");

        });

      }

      

      var rectangleIcon2 = document.getElementById("rectangleIcon2");

      if (rectangleIcon2) {

        rectangleIcon2.addEventListener("click", function () {

          window.open("https://melopatisserie.com/");

        });

      }

      </script>

      <nav>

  </body>

</html>

