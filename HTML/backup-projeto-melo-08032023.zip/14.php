<!DOCTYPE html>

<html>

  <head>

    <meta charset="utf-8" />

    <meta name="viewport" content="initial-scale=1, width=device-width" />

    <meta name="viewport" content="width=device-width, initial-scale=1.0, max-scale=1.0">





    <link rel="stylesheet" href="./14.css" />

    <link rel="stylesheet" href="./14_b.css" />

    <link

      rel="stylesheet"

      href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&display=swap"

    />

  </head>

  <body>

    <div class="profile-exemplo-pgina-com">

      <div class="profile-exemplo-pgina-com-child"></div>

      <div class="profile-exemplo-pgina-com-item"></div>

      <br> <p> <div>

      <div class="hello-michael-hamilton">Hello, michael_hamilton</div>

  

      <div class="my-collectible-delights">My collectible delights</div>

      <div class="page-2">Page 2</div>

      <div class="collectibles">collectibles</div>

      <div class="connections">connections</div>

      <div class="chats">chats</div>

      <div class="parent">

        <div class="div">4</div>

        <img class="group-child" alt="" src="https://d1xzdqg8s8ggsr.cloudfront.net/63adaa2b2434a4e554746687/675069a2-cc50-43f4-acea-8830e3ef2c2f_1672325708142920928?Expires=-62135596800&Signature=Ih4leq-VyefEKuDLFEEuXPLrj8Nl1FkbexZWFz6HCdhpnO99o7G4GL7kdc8xN7reAVx7dOq2nZjdCCYmkB0W5aeF5D5olEj89E65~-Ng7MjhzDwL9tCny6LOFAbymKbyIsQ7YkZNbZH~e7L5a6OAS1LPLzFtiUJi4WoLdDdr3a61KTdzHPHXyhe53Ltw1Zp2A5RDmTyYDql-Bsw6473i8jJm~g8u6vRIujq9pGWNiIIqizoarT8tPzKWnRu94LHoMPHLU9wwHbgyQcUpKx3k23AD1N2BcR~dCypDZfoEPokY6AgBdYEyP5YOuTwRwdqZV75KKWZ4FqiN70GutoqhaA__&Key-Pair-Id=K1P54FZWCHCL6J" />

      </div>

      <div class="group">

        <div class="div1">11</div>

        <img class="group-item" alt="" src="https://d1xzdqg8s8ggsr.cloudfront.net/63adaa2b2434a4e554746687/22028501-bddc-4e4d-af8b-5528f729e164_1672325708143104109?Expires=-62135596800&Signature=Repi~TREpyyEYebhlUpiq0gK9gtBSAMrbDisjppC29-Q6aUt4cfWsdrl5vyimB6C1IGXlzCg9IXagJydjHsPd2SjMdgN6VhVAhGCaWbG3mZ-lbLl2CbjaNaO3D-Oi~fnC6yrsr2Kj8WC-GUb0g5P5jzlsnmnNon6EQn0eVLeLadnfkIEWNb93MHdy~FT~6KorPZmy3554Uj7DbjQrvSaJ5ZCzqQz7sgICpiuac7XguniqD4Zl53-f7RS76Vbx1pQsQx8InQaLJemWTdX4L3rXhcm4su50C9sBfGiSEbGAyViVW1kiA9EX3iqMwgKwEuv9rCoxolNpirqWHCrc3fU2A__&Key-Pair-Id=K1P54FZWCHCL6J" />

      </div>

      <div class="container">

        <div class="div2">2</div>

        <img id="chat" class="group-inner" alt="" src="https://d1xzdqg8s8ggsr.cloudfront.net/63adaa2b2434a4e554746687/ca7cb84a-cd4b-4f2c-af39-5e40c8ff6bba_1672325708143199097?Expires=-62135596800&Signature=R3C1kTxUjtFsLhcpbD8D2kM17t2Mn-kTRPCt7sf9To-YGsJlrPnoo-rW9BwaH4bCQLZJpVWylylk~oMV~sOWaCGIcnpr1FnREkeixsOkWG9GjAh5z~d38sgMuZZNoUgWz-fBzZ~JguL5GV5lRVpGZK8tn0PkHR5am8cqpL7KNGrBtckRAXnpZveQwvwTPPkK2sTXvn0iippB~VbstlppbLS9y1Fo9xhDfN3HqPMiPeUzZ1gObVvDXFJtFbRvJL25r7O01WF0E~pBunA8AhduPT702lu9PulsXRkS2ifSd2kr4IV3h0ICRPHBcI4CgMSSwFzm1FsuS3vMgJRsBMQmyg__&Key-Pair-Id=K1P54FZWCHCL6J" />

      </div>

      <br>

      <div class="a-delightful-christmas">A delightful Christmas</div>

      <br>

      <img

        class="profile-exemplo-pgina-com-inner"

        alt=""

        src="https://d1xzdqg8s8ggsr.cloudfront.net/63adaa2b2434a4e554746687/86ac9956-896e-4926-866f-30a3afcec0a8_1672325708143291550?Expires=-62135596800&Signature=omoQBOgEsl8Nbwvz5GJpmqgMbPfYEvP6S-eoGzLcYRYqmZDglrbzsjJ-Kd8suLtIXu-80259URrRQQuVBTCN1GmdnWfGTmsNcwzS6kmfYkFBTczWzG6NltDMKTUW4V7dSDBMnrKdPuEQzB6v2EPh3VNsBMECDALxKx9UrvDe-JRskMmxUPnhVa6KgJSBJYTBMuvGKIYU~qYATRDZGV1w3ppgfxItCtN7y80bFHfn1YPGLAk7lOVyAKxu2T1eWlNkonm1rdK5LBtFiKUGNxgo~dHf2G~cWpr8MDg3xgyKwJwsNMitNl-xbX3hA7wsPH4JV0vK4~7eDdqhKsjykoHlBg__&Key-Pair-Id=K1P54FZWCHCL6J"

      /><img

        class="rectangle-icon"

        alt=""

        src="https://d1xzdqg8s8ggsr.cloudfront.net/63adaa2b2434a4e554746687/b5d6d994-ef13-436c-9264-12b0aa7c9b64_1672325708143388870?Expires=-62135596800&Signature=v774Ik4ZGz7bzCB0ma5ttpqVQhXHQkFmVjRwqn89kHYsNNIk96I4zeBK2PctSMNh6tjRMLHqo-O1ZtzCzxszKXGWP8pq27zM0YnnvPR0GlaDw81Ltg3BYmL8aigXbJpg9yF~VzkNYKZCulusfcWrxIAHzm9rP7G8LAjUIPHnJkNf2TkyagAwCX2OQp4nBA4E7TZm3KbJDqsDCAr4XHVooYJcaBBfBXDK~KTJK5aO8IQqPHbTu-XqeGHsNzvzhMNTy2kUj816bU2L4AgENGrlvdESnd4g5riCxKANDK538l5J1b8-1kHhS4krDs3J1YG-C5hrz3-iKXdmqW-FPraasQ__&Key-Pair-Id=K1P54FZWCHCL6J"

      /><img

        class="profile-exemplo-pgina-com-child1"

        alt=""

        src="https://d1xzdqg8s8ggsr.cloudfront.net/63adaa2b2434a4e554746687/4104cb81-c699-4596-be4f-fa2f055cf16c_1672325708143476118?Expires=-62135596800&Signature=k3j6d3fwT3xb0Jzj1fhCPSRYa0BMxc2fIa3r1QGowjM5g91CdPMqe1QU5XslnaOfpusHK4iehm0OYBg9pwd0ZeBknqJ41bIrd9LpvY07EB2XlxQ9NxNMdCONKcaGku7O6jux66aReslgh5GBcTJNXwHo4v2OmG3l7wlQZ-sMRMaeKH8S89Xunsezxa3HnyiixOu-O6AaoG5AXeT0yQU4vdUzNVg~DFARpmBardzl-lcj0lAj~t6IOFRBeZBaA73sUnKwBtS3QEmXkNVNcWOo8XemSd3OScEbTzcTmEPgwOJ9LrlRe92eADB93gH5D6km68jT44aGpUnDQfEYEjTMEw__&Key-Pair-Id=K1P54FZWCHCL6J"

      /><img

        class="profile-exemplo-pgina-com-child2"

        alt=""

        src="https://d1xzdqg8s8ggsr.cloudfront.net/63adaa2b2434a4e554746687/4603f359-8915-448f-860e-2880300578ea_1672325708143564155?Expires=-62135596800&Signature=pPcr1vUjE3BWBh7YZxpIa4ybVDc8t7P9FdIFD0hKshBmuZY9loUu44TP9F9bRpgz7sPXUPMHMcvD2PtYEAh6iGZER1lpb4bmZGVjve~PX8fZZwIS0gAkZmzsFI4lQJ2pc4ZL4Ay7vncUiDaH1ZUKysBbI2Mw1N8wQzlF5J6y-CUbuEkOaqSA8VU38Zc-Q48WdlsAoxXV6f5l6SwL65lBe3K5jxFPO34bX3qg03y3EWYZWibDOnAJgz2PZ7~SZXVhadcm3kpCyfwlmFtKN~aSVYAo9q-Y91GrxNpo-m8tjSmYKHL~V5SnhZigpa6O-t5WJNkrqulP477gRqXSBH9x1g__&Key-Pair-Id=K1P54FZWCHCL6J"

      /><img

        class="profile-exemplo-pgina-com-child3"

        alt=""

        src="https://d1xzdqg8s8ggsr.cloudfront.net/63adaa2b2434a4e554746687/b72c6fc2-000b-4fce-a35f-848a54224b65_1672325708143649935?Expires=-62135596800&Signature=EijgDz~OPXRbMXv3TETuufNkhKHpT1HTPzhhpEN0mpsU3BXlCROrb99oLtNMowCKSg2wmIN2tJ-Mz7n8zh81pCOrBHFNGz7X7Fqqp8~3aH30xC1O0mjOG7~vT~059BFWjDl4zw~8hA~7dxDnFTFfrFNhnvHihtWxT2I-HD-1kEyiSOah6feifNQc39oBs0IlHFkbziDf0PhQWOhqwEdMGGHsW4B-mQCmfZDA-6ZnvJBoFAIqgM4C0FIjjHHkkKcYLkCsEssZYSzrWYm1~brG28Q0Gm7X1KbwX1bOmWcSqV9eTRvL-gHB7Ub1xRVFosysHmAT1QJ8-hSvOMd6LV4TdQ__&Key-Pair-Id=K1P54FZWCHCL6J"

      /><img

        class="profile-exemplo-pgina-com-child4"

        alt=""

        src="https://d1xzdqg8s8ggsr.cloudfront.net/63adaa2b2434a4e554746687/7791187a-0004-41eb-8814-a44a83962d57_1672325708143745331?Expires=-62135596800&Signature=UhHhjU31UVo4XTBCCP-zjZMopxQ5xhnF0rmnBsXXXOhWBJS6XXnUiDcgSg71TBUcFmVbAoaldOn7dzhtlByK4d0bzD2TbLUKs1jdYWKFP1helfwWJmfjtHgCZo4oUstaejAuIM9LZkkzQbdGrqn4joBu9QWmyIUP0tZaK8npvVV8TN-i9TQCTnkuALGy-R4MDQexkporvgRfyx3qyphu2a5TyeyJv6ONcusbn9axRHfYRqxgBYgL0~EQLWkKEOypUYdjK-9sYbCbZF2B8JEf8Nbjr9LQSSipRK89pF4IOOqMSml09yKHhceOeKy~71CK-87aFlJEnTfkPID9neu07A__&Key-Pair-Id=K1P54FZWCHCL6J"

      /><img

        class="profile-exemplo-pgina-com-child5"

        alt=""

        src="https://d1xzdqg8s8ggsr.cloudfront.net/63adaa2b2434a4e554746687/22e5e6ad-c9f7-44fc-a7d4-529c093fe4e0_1672325708143834366?Expires=-62135596800&Signature=Ks3ty3CdFF8oMooPkakPpHt2EjUKdPZUkBEjoIvlWGeFAIcfvWbC2JXWx-n~kWF51B7oNqbdCnDsgNEy5~CD1HeZh9mYhVSTJteuLl10DtRk2zZ65IIX3FehDLEG2X2xHDdmZ9NHizmeH5yD9FRZQvvVk~xJWMa3LXr-~FwJn8DRnugQ0Q1lLxxwUBVLHG7iP6m8IjlnHXqKVD04khSkI3gTkmob7c~JrlC9s7iF67Enide6x07N-KWNhYBwYZyUDzJ2W76Nji2lWs8ni1ftS1F-tdkpz26iKvHcovMHP6om7TCOCzpkKP6vi31JNOdmqb8yeEfRg3bDFzJpDBr8Iw__&Key-Pair-Id=K1P54FZWCHCL6J"

      /><img

        class="profile-exemplo-pgina-com-child6"

        alt=""

        src="https://d1xzdqg8s8ggsr.cloudfront.net/63adaa2b2434a4e554746687/8ff2f010-57ea-4614-a69a-7fdda16758ae_1672325708143920095?Expires=-62135596800&Signature=C7qDbM5Vnu4hI~ZRabVa9i2vkCqAw0BXNqtSUoy5Cv8yowkEK1i9OqpTJE8tAygG2Bb2uBnD3eMYC-l9NFg5WxlsQl5VrrXItQFJfXGpKNjfIQRHmauzzBHeE7ihCWOUvc7KtEk58VynsysrLUXeqOkreSiWZswjEMavsdzFnx1CMe7P0LgA8~WrWCKXOagPVNcrsq6E-dnQRl6QyGcqY-ndhui3Njjq2YRH3iXUzhpFFaHukd1Upu2-XDQ6~9li4xp9oNuGvao2YCD1dMxnSXm4oO-38YS-RvvGGTjQt3oaKVV4ETSrW9gjRXt2GZ4DHTSGLOZkXbpVeX77bHa96w__&Key-Pair-Id=K1P54FZWCHCL6J"

      /><img

        class="profile-exemplo-pgina-com-child7"

        alt=""

        src="https://d1xzdqg8s8ggsr.cloudfront.net/63adaa2b2434a4e554746687/87e018b3-b67d-4307-a638-f7fc35cce6b4_1672325708144007679?Expires=-62135596800&Signature=t0O0jBwbF2Tn-jhkvGh5oFyA2q7h5AKOHC-jnNbRx~-PjBAvBTJj7FiIwlDifs223hPAiOiffz68hGJ6zJHv5Oy8yEv~LBjeFDlKr1z2OUn1EaaeqC52jgCJXUReWaFw3f94T~jttLhWlmU19YaWiX~kQp9RzXNEMLVC3wOxoQkqBN-P5SB3hQjZvExkjh9VnAvHhPl7fOJnAPa1b5EFT6Of2HdWI8z0rHTt2xny4XcJGnSNS~qKfKc30yrS~SBaunMey2tk264N~r-APRSqBWBdicaTI9cen-lNR~-GlHhh-5~KO~lXy-~XSXueVj57TWYtjyViiA6zP3dXkTno~w__&Key-Pair-Id=K1P54FZWCHCL6J"

      /><img class="menu-icon" alt="" src="https://d1xzdqg8s8ggsr.cloudfront.net/63adaa2b2434a4e554746687/46ca862d-5c1d-4b3f-b8ac-09a729c3676b_1672325708144090195?Expires=-62135596800&Signature=smYoofQWBItgRUDGD2DKBzX1fGIX3k5xIJi3K3z8NlWV9ERuZmJl8JTop~nPb6NZOp5MrsmR~CGXYve-zf-IcrA2R~NvOuZWGnKhFx26SCJfMolQx38JfCq7upfJEBD9i8sNpYCM9vXAA9iIhG6tw~0ewoswRmyvXkYAMtDAYLmVD-D3N4r1KhwbGRwwlsQPSWrPGVVLuQ6SUplPNCkYiDw6DhWN1u09nASoAFaas51877o1nza68AcI73pnqhtVQwWRvPmaWDztqmx0eUJfjIMLFcks3~bkQCMxaJIZ4m7RyeBl9oWKxLRNXpQJRFx5wDx3Kikdpf7tfkD58dNFTg__&Key-Pair-Id=K1P54FZWCHCL6J" /><img

        class="icon-new-treat"

        alt=""

        src="https://d1xzdqg8s8ggsr.cloudfront.net/63adaa2b2434a4e554746687/22d76545-ec2c-4fda-816b-4b9826f3299a_1672325708144173486?Expires=-62135596800&Signature=CsXhZoMDdeiB-7D6HmgJtT0vSTbZ43DrkRHRfPE~vilCdBHSGYydZJ60Jp7WfLteC5hibz2RlR6yLYlSCgSSJY4sFa0cvDYdaKv2j1ouEVzRFJ7EJ6qJWcES6I~7MHKnyXnLcZOeEjdZzXWmc44n3scIeHEfE7nGD8Wyy~pYv~DJ-SvCqSPRfq10TdHq5mK6Orp~U8n~aGJu8mkyMJnJdVkHrAu8vfQ1C3~TppvJsvLMPyO9dGW50wiN~KMPm39Lip2g15SggjBuXb41IukpZ8TBGsnN1HdX35Jhr3U5D1grDuWv2DWJqftBhjn20OZKjjFWGltRVuyPDosKleNGoQ__&Key-Pair-Id=K1P54FZWCHCL6J"

      />  <img

      class="profile-exemplo-pgina-com-child8"

      alt=""

      src="https://d1xzdqg8s8ggsr.cloudfront.net/63ad95cc2434a4e554746314/d825aaaf-433f-47bb-90d3-ffc173ac637c_1672320469889016661?Expires=-62135596800&Signature=VKrnXJ7h~t9RBflLL6-4MWGWETUIdgPEIAeOmKXyDCZtgClxa1i6XUKkR~D43QhWmvkfQb6drBb7T~Q6Fo2RQSta7T9pfVsnvafEsM1wPyScN1MvM6hj4XrdssZH0keG6bIos16Y5mLOOd2nUucP1~6C3bAmLIhBzGLBWqCmZ7YDsCPVSqt1f9c7nK4xGY310USzRRW~~dfobcRgGykkTc2L~XhUklDW3Pi2CBeCdTWATtz2l96ejGGznVUeY8p27vuyfL2N8UeYsGImkbOAM2eNvn7yGBPCc8RaZvnmMcXBK1ujGcbh8FWQAn1pokRyzgy3aDuLKcZkL3zlt4IfeA__&Key-Pair-Id=K1P54FZWCHCL6J"

    /><img class="edit-icon" alt="" src="https://d1xzdqg8s8ggsr.cloudfront.net/63ad95cc2434a4e554746314/38e67f40-2638-42b5-a562-c9d75f0ff206_1672320469888282945?Expires=-62135596800&Signature=jl9iQdm~dDlZHzPSYezXr8I8rIiybTSD17n-ACTgaWJiw-GzEm-px7rMuECC5nT5eaVFAAM~XU26GMZTYRFHGoeVQAfiHaoH1QImxP86~4AOiI0QSNx41~p163-iyKNCbCr2xkm4nvl-00F7VnfK8Ct25ljGh0bwLYDwTzXJFEV-M5aCs-y9Y10z7ARX4RnNBU-pygie5IPCn51do5xvrW2sDoQHfHdIHgelUJfa1rSGYWL859oxNUl50rYnKyl52s7~iKD2qrR8K961EuYdtE-kWXe3usniNNxlE5gwqU-psDqjBT0U11Yrf12YPBefS7zRChbAZysIpgLVMNE7aw__&Key-Pair-Id=K1P54FZWCHCL6J" />

    <div class="fixed-itens-bg-superior"></div>

      <div

      form id="search" class="search-bar">

        <div class="barra-de-pesquisa"></div>

        <input type="text" id="search-bar" class="search-bar" placeholder="Search">

        <a href="#"></a>

      </form> 

    </div>

     <img class="icon-side-menu" alt="" src="https://d1xzdqg8s8ggsr.cloudfront.net/63adaa2b2434a4e554746687/f8491da2-3b82-44fa-a12c-507e834c5db5_1672325708144518547?Expires=-62135596800&Signature=Gtn31AYH2D5zFfIIhObRPjBuVQsKP3E3g28JSXbKCi0GIMby6cgbggHGBk-UPdDcyTS6eLyOtBAD5LLLVXzCcpJEabt5UrZbDVYb3V4z16RlwrAiFTtlVw5BJjPjjDC4ukkSZwUZTltYbS7Tt1d9Ovpz2JDR8H0hA4~6s8BPgB93kr0A1WOP-glcKYz6nXY6xXwKTovEbc~Vz3NiwmYPLHWvXRpzBiTRJPTvTNXKnaK9GMZzLAjSKPPS2kbZr4spgLYXZc9wLJlWe0hfo-Y2xOpJJ0HkjffsKJo-mSQ0iy4Kutuq4ywgRd4ZB~UPStsKxexF53~D6mwhWDe4nv5s1g__&Key-Pair-Id=K1P54FZWCHCL6J" />

      <div class="menu-inferior"></div>

      <div class="icon-home-in-parent">

        <img id="home" class="icon-home-in" alt="" src="https://d1xzdqg8s8ggsr.cloudfront.net/63adaa2b2434a4e554746687/3a5d7375-88eb-4d2c-ab9e-cbafcf4a11d7_1672325708144603483?Expires=-62135596800&Signature=MN6RLRtxogJuj1pJ~52~LJ~Wky~3xR7f3Atr98r~hIpbiP7S-ene311tNEAEMmnwmNBYR4aZxZDte6dF-aGetpoFUoiKMebS0P-qyQhrUAywOaALYSfBfeSUr-XPK86PXR59iPid5wN0Em70R2GELviAdISBvR4Gkw1A2NvuA66lmE-FAKOYaJq~zzlVc4A7YDCIGpZ3yrYfKounD5pFaEIdTJjXKzkNtGrBSGdj0NqRRmmJLzsXt9DoG2rK7WhlXtTBnBShFVCjJ0qM92X7fFmLjjJJzDx1xRdZcWa8xN~PW6cM0toYVtsuDNNUp4jAjlGRI9uiun9l6yUDkqxrcQ__&Key-Pair-Id=K1P54FZWCHCL6J" />

        <div class="home">Home</div>

      </div>

      <div class="profile">

        <img id="pvdu"

          class="icon-profile-out"

          alt=""

          src="https://d1xzdqg8s8ggsr.cloudfront.net/63adaa2b2434a4e554746687/60679cd1-0520-4eb4-bf4f-64865eaf6d4d_1672325708144682724?Expires=-62135596800&Signature=gPk6d7jAkTCy6uZNmrvep3Nlnvm-hQZReDkWev99ERiw4Hw3aXrRDEE76RARPCTNqKDKUvcTKAcbeEFQHQ-qupwfaKwgFNyyo-Ajg4GqNj0mC3xYDzVlfScYZ8x2hRkDu8J0k-tsRAXKo1nC56ommEPsEpuKqWrHslNrOZTzEy6SDFFMvgXp6-v4MWMw9H3W4CGT-Cy~s3OfDTS~NEff0k04D~kkt--FjHtfWL9SE~amLp0l7KMTBzjvy-yZCyrUPY97JE4~hq-GXcCORbEOfBtJAA4z~mvvPyC4mXGV5oZ26BnGg85iwRyMPKK3Fyjb~85VhrIPPdRzKo0ooiXKyA__&Key-Pair-Id=K1P54FZWCHCL6J"

        />

        <div class="profile1">Profile</div>

      </div>

      <div class="profile2">

        <img id="usuarioc"

          class="icon-profile-out1"

          alt=""

          src="https://d1xzdqg8s8ggsr.cloudfront.net/63adaa2b2434a4e554746687/00f094cf-c5e8-43b6-94dd-92d187ffbe86_1672325708144773417?Expires=-62135596800&Signature=iUhOY4VR9Pe-xi9e9r6V6U1BSYdib848WTPZ1C~jVlypsTH4q8vk56SvSNx7YoOwo6v-yJ~WE1Ic1hGAT2EIPyEhlhyGlmd9g0vbpAK9f~hau0Q2DmzxyvTfkXnHJElpvXqP3ee7ga3r6WgZt8cofUizBQdHPAKw2QjYYztqGxEiLZ7Er7rYeUNAAq4GE-~Vrz44X6rKom5sIyYSSF1Z0e-vXpLmImx1Zu49vQXAOA9xOWJ~EKUtMt2UMtfY4hSBR3L7x~EEOGdMOo9Zow~JX4ppq74tOTD2oATJUyMtcCUH1AY1nJRGn0GEHkUbKfvCFMITUBL1uA9wkVSCPMJvLA__&Key-Pair-Id=K1P54FZWCHCL6J"

        />

        <div class="home">Community</div>

      </div>

      <div class="rectangle-parent">

        <img class="group-child1" alt="" src="https://d1xzdqg8s8ggsr.cloudfront.net/63adaa2b2434a4e554746687/8bac4b22-f62a-4ec4-aa00-c38f8dd30c1d_1672325708144887253?Expires=-62135596800&Signature=tbbbpMI1M47NmNK9v1fNoP0yCz2L4yEMgKEwuIYBX0hOyehfutJL7fwyhIHiet~52TKd1xF0MuaO-Zs0OlqEOo0GtneZvE-5Kzvimbt97e5FF54Hs~BkO4G5PK3~EfcyXNA11MtThjdo6BnfZf3cEUAaMdjKsV17NlbnE5KNcNJeptJSvsK4ui59OGMNby~KolG1ynUYkhVB2F9o4C7BLdREdbNOnDajgq5V99p44mOrabNcnQuLASr5eIJsb85Tt2UmNP~OSV4IWj7np7B7nsZTls4NcPp16ralYAgcKDlTPAIyhTO5BM12R3zJEVOuD7~jsqKXuMRFIAGICj3zqQ__&Key-Pair-Id=K1P54FZWCHCL6J" />

        <div class="my-collectibles">My Collectibles</div>

      </div>

    </div>

      <script>    

    var chat = document.getElementById("chat");

    if (chat) {

      chat.addEventListener("click", function () {

        window.open("chats.html");

      });

    }

    var usuarioc = document.getElementById("usuarioc");

    if (usuarioc) {

      usuarioc.addEventListener("click", function () {

        window.open("usuarioc.html");

      });

    }

    var pvdu = document.getElementById("pvdu");

    if (pvdu) {

      pvdu.addEventListener("click", function () {

        window.open("pvdu.html");

      });

    }

    var home = document.getElementById("home");

    if (home) {

      home.addEventListener("click", function () {

        window.open("pvdu.html");

      });

    }

    </script>

  </body>

</html>

