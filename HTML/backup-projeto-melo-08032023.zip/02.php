<!DOCTYPE html>

<html>

  <head>

    <meta charset="utf-8" />

    <meta name="viewport" content="initial-scale=1, width=device-width" />



    <link rel="stylesheet" href="./02.css" />

    <link rel="stylesheet" href="./02_b.css" />

    <link

      rel="stylesheet"

      href="https://fonts.googleapis.com/css2?family=Inter:wght@600;800&display=swap"

    />

  </head>

  <body>

    <div class="modal-are-you-sure">

      <div class="modal-are-you-sure-child"></div>

      <div class="are-you-sure-of-this-action">

        Are you sure of this action?

      </div>

      <div class="yes">YES</div>

      <div class="cancel">cancel</div>

    </div>

  </body>

</html>

