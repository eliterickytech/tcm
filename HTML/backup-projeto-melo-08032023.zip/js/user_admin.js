$(document).ready(function () {
    $("form").submit(function (event) {
        var spinner = $('#loader');
        var formData = {
            user_email: document.querySelector('[name="user_email"]').value,
            password: document.querySelector('[name="password"]').value,
            confirm_password: document.querySelector('[name="confirm-password"]').value,
            type: document.querySelector('[name="type"]').value,
            user_id: document.querySelector('[name="user_id"]').value,
            user_registry_key: document.querySelector('[name="user_registry_key"]').value,
            session: document.querySelector('[name="session"]').value,
            token: document.querySelector('[name="token"]').value,
            user_group: document.querySelector('[name="user_group"]').value,
        };
        $(".form-group").removeClass("has-error");
        $(".help-block").remove();  
        var dados = JSON.stringify(formData);
        spinner.show();
        $.ajax({
            type: "POST",
            url: "user-admin.php",
            data: {data: dados},
            dataType: "json",
            encode: true,
        })
        .done(function (data) {
            spinner.hide();
            console.log(data);
            if (!data.success) {
                if (data.errors.password) {
                $("#password-group").addClass("has-error");
                $("#password-group").append(
                    '<div style="color:#C0694E;" class="help-block">' + data.errors.password + "</div>"
                );
                }
                if (data.errors.confirm_password) {
                $("#confirm-password-group").addClass("has-error");
                $("#confirm-password-group").append(
                    '<div style="color:#C0694E;" class="help-block">' + data.errors.confirm_password + "</div>"
                );
                }
                if (data.errors.email) {
                $("#email-group").addClass("has-error");
                $("#email-group").append(
                    '<div style="color:#C0694E;" class="help-block">' + data.errors.email + "</div>"
                );
                }
            } else {
                $(".access").remove();  
                $("head").html(
                    data.redirect
                );
            }
        })
        .fail(function (data) {
            spinner.hide();
            if (!data.success) {
                $("form").html(
                '<div  style="color:#C0694E;" class="alert alert-danger">Could not reach server, please try again later.</div>'
                );
            }
        });
      event.preventDefault();
    });
});
