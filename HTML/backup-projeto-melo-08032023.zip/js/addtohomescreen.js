!(function (e, t) {
    function i() {
        e.removeEventListener("load", i, !1), (r = !0);
    }
    function n(e) {
        return (l = l || new n.Class(e));
    }
    function o(e, t) {
        for (var i in t) e[i] = t[i];
        return e;
    }
    function s() {
        "#ath" == t.location.hash && history.replaceState("", e.document.title, t.location.href.split("#")[0]),
            d.test(t.location.href) && history.replaceState("", e.document.title, t.location.href.replace(d, "$1")),
            h.test(t.location.search) && history.replaceState("", e.document.title, t.location.href.replace(h, "$2"));
    }
    var a = "addEventListener" in e,
        r = !1;
    "complete" === t.readyState ? (r = !0) : a && e.addEventListener("load", i, !1);
    var l,
        d = /\/ath(\/)?$/,
        h = /([\?&]ath=[^&]*$|&ath=[^&]*(&))/;
    n.intl = {
        cs_cs: {
            ios: "Pro p\u0159id\xe1ni t\xe9to webov\xe9 aplikace na \xfavodn\xed obrazovku: stla\u010dte %icon a pak <strong>P\u0159idat na \xfavodn\xed obrazovku</strong>.",
            android:
                'Pro p\u0159id\xe1ni t\xe9to webov\xe9 aplikace na \xfavodn\xed obrazovku otev\u0159ete menu nastaven\xed prohl\xed\u017ee\u010de a stla\u010dte <strong>P\u0159idat na \xfavodn\xed obrazovku</strong>. <small>K menu se dostanete stla\u010den\xedm hardwaroveho tla\u010d\xedtka, kdy\u017e ho va\u0161e za\u0159\xedzen\xed m\xe1, nebo stla\u010den\xedm prav\xe9 horn\xed menu ikony <span class="ath-action-icon">icon</span>.</small>',
        },
        de_de: {
            ios: "Um diese Web-App zum Home-Bildschirm hinzuzuf\xfcgen, tippen Sie auf %icon und dann <strong>Zum Home-Bildschirm</strong>.",
            android:
                "Um diese Web-App zum Home-Bildschirm hinzuzuf\xfcgen, \xf6ffnen Sie das Men\xfc und tippen dann auf <strong>Zum Startbildschirm hinzuf\xfcgen</strong>. <small>Wenn Ihr Ger\xe4t eine Men\xfctaste hat, l\xe4sst sich das Browsermen\xfc \xfcber diese \xf6ffnen. Ansonsten tippen Sie auf %icon.</small>",
        },
        da_dk: {
            ios: "For at tilf\xf8je denne web app til hjemmesk\xe6rmen: Tryk %icon og derefter <strong>F\xf8j til hjemmesk\xe6rm</strong>.",
            android:
                "For at tilf\xf8je denne web app til hjemmesk\xe6rmen, \xe5bn browser egenskaber menuen og tryk p\xe5 <strong>F\xf8j til hjemmesk\xe6rm</strong>. <small>Denne menu kan tilg\xe5s ved at trykke p\xe5 menu knappen, hvis din enhed har en, eller ved at trykke p\xe5 det \xf8verste h\xf8jre menu ikon %icon.</small>",
        },
        el_gr: {
            ios:
                "\u0393\u03b9\u03b1 \u03bd\u03b1 \u03c0\u03c1\u03bf\u03c3\u03b8\u03ad\u03c3\u03b5\u03c4\u03b5 \u03c4\u03b7\u03bd \u03b5\u03c6\u03b1\u03c1\u03bc\u03bf\u03b3\u03ae \u03c3\u03c4\u03b7\u03bd \u03b1\u03c1\u03c7\u03b9\u03ba\u03ae \u03bf\u03b8\u03cc\u03bd\u03b7: \u03c0\u03b1\u03c4\u03ae\u03c3\u03c4\u03b5 \u03c4\u03bf %icon \u03ba\u03b1\u03b9 \u03bc\u03b5\u03c4\u03ac <strong>\u03a0\u03c1\u03cc\u03c3\u03b8\u03b5\u03c3\u03b5 \u03c3\u03c4\u03b7\u03bd \u03b1\u03c1\u03c7\u03b9\u03ba\u03ae \u03bf\u03b8\u03cc\u03bd\u03b7</strong>.",
            android:
                "\u0393\u03b9\u03b1 \u03bd\u03b1 \u03c0\u03c1\u03bf\u03c3\u03b8\u03ad\u03c3\u03b5\u03c4\u03b5 \u03c4\u03b7\u03bd \u03b5\u03c6\u03b1\u03c1\u03bc\u03bf\u03b3\u03ae \u03c3\u03c4\u03b7\u03bd \u03b1\u03c1\u03c7\u03b9\u03ba\u03ae \u03bf\u03b8\u03cc\u03bd\u03b7, \u03b1\u03bd\u03bf\u03af\u03be\u03c4\u03b5 \u03c4\u03b9\u03c2 \u03b5\u03c0\u03b9\u03bb\u03bf\u03b3\u03ad\u03c2 \u03c4\u03bf\u03c5 browser \u03c3\u03b1\u03c2 \u03ba\u03b1\u03b9 \u03c0\u03b1\u03c4\u03ae\u03c3\u03c4\u03b5 \u03c4\u03bf <strong>\u03a0\u03c1\u03bf\u03c3\u03b8\u03ae\u03ba\u03b7 \u03c3\u03c4\u03b7\u03bd \u03b1\u03c1\u03c7\u03b9\u03ba\u03ae \u03bf\u03b8\u03cc\u03bd\u03b7</strong>. <small>\u039c\u03c0\u03bf\u03c1\u03b5\u03af\u03c4\u03b5 \u03bd\u03b1 \u03ad\u03c7\u03b5\u03c4\u03b5 \u03c0\u03c1\u03cc\u03c3\u03b2\u03b1\u03c3\u03b7 \u03c3\u03c4\u03bf \u03bc\u03b5\u03bd\u03bf\u03cd, \u03c0\u03b1\u03c4\u03ce\u03bd\u03c4\u03b1\u03c2 \u03c4\u03bf \u03ba\u03bf\u03c5\u03bc\u03c0\u03af \u03c4\u03bf\u03c5 \u03bc\u03b5\u03bd\u03bf\u03cd \u03c4\u03bf\u03c5 \u03ba\u03b9\u03bd\u03b7\u03c4\u03bf\u03cd \u03c3\u03b1\u03c2 \u03ae \u03c4\u03bf \u03c0\u03ac\u03bd\u03c9 \u03b4\u03b5\u03be\u03b9\u03ac \u03ba\u03bf\u03c5\u03bc\u03c0\u03af \u03c4\u03bf\u03c5 \u03bc\u03b5\u03bd\u03bf\u03cd %icon.</small>",
        },
        en_us: {
            ios: "To add this web app to the home screen: tap %icon and then <strong>Add to Home Screen</strong>.",
            android:
                "To add this web app to the home screen open the browser option menu and tap on <strong>Add to homescreen</strong>. <small>The menu can be accessed by pressing the menu hardware button if your device has one, or by tapping the top right menu icon %icon.</small>",
        },
        es_es: {
            ios: "Para a\xf1adir esta aplicaci\xf3n web a la pantalla de inicio: pulsa %icon y selecciona <strong>A\xf1adir a pantalla de inicio</strong>.",
            android:
                "Para a\xf1adir esta aplicaci\xf3n web a la pantalla de inicio, abre las opciones y pulsa <strong>A\xf1adir a pantalla inicio</strong>. <small>El men\xfa se puede acceder pulsando el bot\xf3n t\xe1ctil en caso de tenerlo, o bien el icono de la parte superior derecha de la pantalla %icon.</small>",
        },
        fi_fi: {
            ios: "Liit\xe4 t\xe4m\xe4 sovellus kotivalikkoon: klikkaa %icon ja t\xe4m\xe4n j\xe4lkeen <strong>Lis\xe4\xe4 kotivalikkoon</strong>.",
            android:
                "Lis\xe4t\xe4ksesi t\xe4m\xe4n sovelluksen aloitusn\xe4yt\xf6lle, avaa selaimen valikko ja klikkaa t\xe4hti -ikonia tai <strong>Lis\xe4\xe4 aloitusn\xe4yt\xf6lle teksti\xe4</strong>. <small>Valikkoon p\xe4\xe4see my\xf6s painamalla menuvalikkoa, jos laitteessasi on sellainen tai koskettamalla oikealla yl\xe4kulmassa menu ikonia %icon.</small>",
        },
        fr_fr: {
            ios: "Pour ajouter cette application web sur l'\xe9cran d'accueil : Appuyez %icon et s\xe9lectionnez <strong>Ajouter sur l'\xe9cran d'accueil</strong>.",
            android:
                'Pour ajouter cette application web sur l\'\xe9cran d\'accueil : Appuyez sur le bouton "menu", puis sur <strong>Ajouter sur l\'\xe9cran d\'accueil</strong>. <small>Le menu peut-\xeatre accessible en appuyant sur le bouton "menu" du t\xe9l\xe9phone s\'il en poss\xe8de un <i class="fa fa-bars"></i>. Sinon, il se trouve probablement dans la coin sup\xe9rieur droit du navigateur %icon.</small>',
        },
        he_il: {
            ios:
                '<span dir="rtl">\u05dc\u05d4\u05d5\u05e1\u05e4\u05ea \u05d4\u05d0\u05e4\u05dc\u05d9\u05e7\u05e6\u05d9\u05d4 \u05dc\u05de\u05e1\u05da \u05d4\u05d1\u05d9\u05ea: \u05dc\u05dc\u05d7\u05d5\u05e5 \u05e2\u05dc %icon \u05d5\u05d0\u05d6 <strong>\u05d4\u05d5\u05e1\u05e3 \u05dc\u05de\u05e1\u05da \u05d4\u05d1\u05d9\u05ea</strong>.</span>',
            android:
                "To add this web app to the home screen open the browser option menu and tap on <strong>Add to homescreen</strong>. <small>The menu can be accessed by pressing the menu hardware button if your device has one, or by tapping the top right menu icon %icon.</small>",
        },
        hu_hu: {
            ios:
                "Ha hozz\xe1 szeretn\xe9 adni ezt az alkalmaz\xe1st a kezd\u0151k\xe9perny\u0151j\xe9hez, \xe9rintse meg a k\xf6vetkez\u0151 ikont: %icon , majd a <strong>Hozz\xe1ad\xe1s a kezd\u0151k\xe9perny\u0151h\xf6z</strong> men\xfcpontot.",
            android:
                "Ha hozz\xe1 szeretn\xe9 adni ezt az alkalmaz\xe1st a kezd\u0151k\xe9perny\u0151j\xe9hez, a b\xf6ng\xe9sz\u0151 men\xfcj\xe9ben kattintson a <strong>Hozz\xe1ad\xe1s a kezd\u0151k\xe9perny\u0151h\xf6z</strong> men\xfcpontra. <small>A b\xf6ng\xe9sz\u0151 men\xfcj\xe9t a k\xf6vetkez\u0151 ikon meg\xe9rint\xe9s\xe9vel tudja megnyitni: %icon.</small>",
        },
        it_it: {
            ios: "Per aggiungere questa web app alla schermata iniziale: premi %icon e poi <strong>Aggiungi a Home</strong>.",
            android:
                "Per aggiungere questa web app alla schermata iniziale, apri il menu opzioni del browser e premi su <strong>Aggiungi alla homescreen</strong>. <small>Puoi accedere al menu premendo il pulsante hardware delle opzioni se la tua device ne ha uno, oppure premendo l'icona %icon in alto a destra.</small>",
        },
        ja_jp: {
            ios:
                "\u3053\u306e\u30a6\u30a7\u30d7\u30a2\u30d7\u30ea\u3092\u30db\u30fc\u30e0\u753b\u9762\u306b\u8ffd\u52a0\u3059\u308b\u306b\u306f\u3001%icon\u3092\u30bf\u30c3\u30d7\u3057\u3066<strong>\u30db\u30fc\u30e0\u753b\u9762\u306b\u8ffd\u52a0</strong>\u3057\u3066\u304f\u3060\u3055\u3044\u3002",
            android:
                "\u3053\u306e\u30a6\u30a7\u30d7\u30a2\u30d7\u30ea\u3092\u30db\u30fc\u30e0\u753b\u9762\u306b\u8ffd\u52a0\u3059\u308b\u306b\u306f\u3001\u30d6\u30e9\u30a6\u30b6\u306e\u30aa\u30d7\u30b7\u30e7\u30f3\u30e1\u30cb\u30e5\u30fc\u304b\u3089<strong>\u30db\u30fc\u30e0\u753b\u9762\u306b\u8ffd\u52a0</strong>\u3092\u30bf\u30c3\u30d7\u3057\u3066\u304f\u3060\u3055\u3044\u3002<small>\u30aa\u30d7\u30b7\u30e7\u30f3\u30e1\u30cb\u30e5\u30fc\u306f\u3001\u4e00\u90e8\u306e\u6a5f\u7a2e\u3067\u306f\u30c7\u30d0\u30a4\u30b9\u306e\u30e1\u30cb\u30e5\u30fc\u30dc\u30bf\u30f3\u304b\u3089\u3001\u305d\u308c\u4ee5\u5916\u3067\u306f\u753b\u9762\u53f3\u4e0a\u306e%icon\u304b\u3089\u30a2\u30af\u30bb\u30b9\u3067\u304d\u307e\u3059\u3002</small>",
        },
        ko_kr: {
            ios: "\ud648 \ud654\uba74\uc5d0 \ubc14\ub85c\uac00\uae30 \uc0dd\uc131: %icon \uc744 \ud074\ub9ad\ud55c \ud6c4 <strong>\ud648 \ud654\uba74\uc5d0 \ucd94\uac00</strong>.",
            android:
                "\ube0c\ub77c\uc6b0\uc800 \uc635\uc158 \uba54\ub274\uc758 <string>\ud648 \ud654\uba74\uc5d0 \ucd94\uac00</string>\ub97c \ud074\ub9ad\ud558\uc5ec \ud648\ud654\uba74\uc5d0 \ubc14\ub85c\uac00\uae30\ub97c \uc0dd\uc131\ud560 \uc218 \uc788\uc2b5\ub2c8\ub2e4. <small>\uc635\uc158 \uba54\ub274\ub294 \uc7a5\uce58\uc758 \uba54\ub274 \ubc84\ud2bc\uc744 \ub204\ub974\uac70\ub098 \uc624\ub978\ucabd \uc0c1\ub2e8\uc758 \uba54\ub274 \uc544\uc774\ucf58 %icon\uc744 \ud074\ub9ad\ud558\uc5ec \uc811\uadfc\ud560 \uc218 \uc788\uc2b5\ub2c8\ub2e4.</small>",
        },
        nb_no: {
            ios: "For \xe5 installere denne appen p\xe5 hjem-skjermen: trykk p\xe5 %icon og deretter <strong>Legg til p\xe5 Hjem-skjerm</strong>.",
            android:
                "For \xe5 legge til denne webappen p\xe5 startsiden \xe5pner en nettlesermenyen og velger <strong>Legg til p\xe5 startsiden</strong>. <small>Menyen \xe5pnes ved \xe5 trykke p\xe5 den fysiske menyknappen hvis enheten har det, eller ved \xe5 trykke p\xe5 menyikonet \xf8verst til h\xf8yre %icon.</small>",
        },
        pt_br: {
            ios: "Para adicionar este app \xe0 tela de in\xedcio: clique %icon e ent\xe3o <strong>Tela de in\xedcio</strong>.",
            android:
                'Para adicionar este app \xe0 tela de in\xedcio, abra o menu de op\xe7\xf5es do navegador e selecione <strong>Adicionar \xe0 tela inicial</strong>. <small>O menu pode ser acessado pressionando o "menu" button se o seu dispositivo tiver um, ou selecionando o \xedcone %icon no canto superior direito.</small>',
        },
        pt_pt: {
            ios: "Para adicionar esta app ao ecr\xe3 principal: clique %icon e depois <strong>Ecr\xe3 principal</strong>.",
            android:
                'Para adicionar esta app web ecr\xe3 principal, abra o menu de op\xe7\xf5es do navegador e selecione <strong>Adicionar \xe0 tela inicial</strong>. <small>O menu pode ser acessado pressionando o "menu" button se o seu dispositivo tiver um, ou selecionando o \xedcone %icon no canto superior direito.</small>',
        },
        nl_nl: {
            ios: "Om deze webapp aan je startscherm toe te voegen, klik op %icon en dan <strong>Zet in startscherm</strong>.",
            android:
                'Om deze webapp aan je startscherm toe te voegen, open de browserinstellingen en tik op <strong>Toevoegen aan startscherm</strong>. <small>Gebruik de "menu" knop als je telefoon die heeft, anders het menu-icoon rechtsbovenin %icon.</small>',
        },
        ru_ru: {
            ios:
                '\u0427\u0442\u043e\u0431\u044b \u0434\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u044d\u0442\u043e\u0442 \u0441\u0430\u0439\u0442 \u043d\u0430 \u0441\u0432\u043e\u0439 \u0434\u043e\u043c\u0430\u0448\u043d\u0438\u0439 \u044d\u043a\u0440\u0430\u043d, \u043d\u0430\u0436\u043c\u0438\u0442\u0435 \u043d\u0430 \u0438\u043a\u043e\u043d\u043a\u0443 %icon \u0438 \u0437\u0430\u0442\u0435\u043c <strong>\u041d\u0430 \u044d\u043a\u0440\u0430\u043d "\u0414\u043e\u043c\u043e\u0439"</strong>.',
            android:
                "\u0427\u0442\u043e\u0431\u044b \u0434\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u0441\u0430\u0439\u0442 \u043d\u0430 \u0441\u0432\u043e\u0439 \u0434\u043e\u043c\u0430\u0448\u043d\u0438\u0439 \u044d\u043a\u0440\u0430\u043d, \u043e\u0442\u043a\u0440\u043e\u0439\u0442\u0435 \u043c\u0435\u043d\u044e \u0431\u0440\u0430\u0443\u0437\u0435\u0440\u0430 \u0438 \u043d\u0430\u0436\u043c\u0438\u0442\u0435 \u043d\u0430 <strong>\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u043d\u0430 \u0433\u043b\u0430\u0432\u043d\u044b\u0439 \u044d\u043a\u0440\u0430\u043d</strong>. <small>\u041c\u0435\u043d\u044e \u043c\u043e\u0436\u043d\u043e \u0432\u044b\u0437\u0432\u0430\u0442\u044c, \u043d\u0430\u0436\u0430\u0432 \u043d\u0430 \u043a\u043d\u043e\u043f\u043a\u0443 \u043c\u0435\u043d\u044e \u0432\u0430\u0448\u0435\u0433\u043e \u0442\u0435\u043b\u0435\u0444\u043e\u043d\u0430, \u0435\u0441\u043b\u0438 \u043e\u043d\u0430 \u0435\u0441\u0442\u044c. \u0418\u043b\u0438 \u043d\u0430\u0439\u0434\u0438\u0442\u0435 \u0438\u043a\u043e\u043d\u043a\u0443 \u0441\u0432\u0435\u0440\u0445\u0443 \u0441\u043f\u0440\u0430\u0432\u0430 %icon[\u0438\u043a\u043e\u043d\u043a\u0430].</small>",
        },
        sk_sk: {
            ios: "Pre pridanie tejto webovej aplik\xe1cie na \xfavodn\xfa obrazovku: stla\u010dte %icon a potom <strong>Prida\u0165 na \xfavodn\xfa obrazovku</strong>.",
            android:
                'Pre pridanie tejto webovej aplik\xe1cie na \xfavodn\xfa obrazovku otvorte menu nastavenia prehliada\u010da a stla\u010dte <strong>Prida\u0165 na \xfavodn\xfa obrazovku</strong>. <small>K menu sa dostanete stla\u010den\xedm hardwaroveho tla\u010didla, ak ho va\u0161e zariadenie m\xe1, alebo stla\u010den\xedm pravej hornej menu ikony <span class="ath-action-icon">icon</span>.</small>',
        },
        sv_se: {
            ios: "F\xf6r att l\xe4gga till denna webbapplikation p\xe5 hemsk\xe4rmen: tryck p\xe5 %icon och d\xe4refter <strong>L\xe4gg till p\xe5 hemsk\xe4rmen</strong>.",
            android:
                "F\xf6r att l\xe4gga till den h\xe4r webbappen p\xe5 hemsk\xe4rmen \xf6ppnar du webbl\xe4sarens alternativ-meny och v\xe4ljer <strong>L\xe4gg till p\xe5 startsk\xe4rmen</strong>. <small>Man hittar menyn genom att trycka p\xe5 h\xe5rdvaruknappen om din enhet har en s\xe5dan, eller genom att trycka p\xe5 menyikonen h\xf6gst upp till h\xf6ger %icon.</small>",
        },
        tr_tr: {
            ios: "Uygulamay\u0131 ana ekrana eklemek i\xe7in, %icon ve ard\u0131ndan <strong>ana ekrana ekle</strong> butonunu t\u0131klay\u0131n.",
            android:
                "Uygulamay\u0131 ana ekrana eklemek i\xe7in, men\xfcye girin ve <strong>ana ekrana ekle</strong> butonunu t\u0131klay\u0131n. <small>Cihaz\u0131n\u0131z men\xfc tu\u015funa sahip ise men\xfcye girmek i\xe7in men\xfc tu\u015funu t\u0131klay\u0131n. Aksi takdirde %icon butonunu t\u0131klay\u0131n.</small>",
        },
        uk_ua: {
            ios:
                "\u0429\u043e\u0431 \u0434\u043e\u0434\u0430\u0442\u0438 \u0446\u0435\u0439 \u0441\u0430\u0439\u0442 \u043d\u0430 \u043f\u043e\u0447\u0430\u0442\u043a\u043e\u0432\u0438\u0439 \u0435\u043a\u0440\u0430\u043d, \u043d\u0430\u0442\u0438\u0441\u043d\u0456\u0442\u044c %icon, \u0430 \u043f\u043e\u0442\u0456\u043c <strong>\u041d\u0430 \u043f\u043e\u0447\u0430\u0442\u043a\u043e\u0432\u0438\u0439 \u0435\u043a\u0440\u0430\u043d</strong>.",
            android:
                "\u0429\u043e\u0431 \u0434\u043e\u0434\u0430\u0442\u0438 \u0446\u0435\u0439 \u0441\u0430\u0439\u0442 \u043d\u0430 \u0434\u043e\u043c\u0430\u0448\u043d\u0456\u0439 \u0435\u043a\u0440\u0430\u043d, \u0432\u0456\u0434\u043a\u0440\u0438\u0439\u0442\u0435 \u043c\u0435\u043d\u044e \u0431\u0440\u0430\u0443\u0437\u0435\u0440\u0430 \u0442\u0430 \u0432\u0438\u0431\u0435\u0440\u0456\u0442\u044c <strong>\u0414\u043e\u0434\u0430\u0442\u0438 \u043d\u0430 \u0433\u043e\u043b\u043e\u0432\u043d\u0438\u0439 \u0435\u043a\u0440\u0430\u043d</strong>. <small>\u0426\u0435 \u043c\u043e\u0436\u043b\u0438\u0432\u043e \u0437\u0440\u043e\u0431\u0438\u0442\u0438, \u043d\u0430\u0442\u0438\u0441\u043d\u0443\u0432\u0448\u0438 \u043a\u043d\u043e\u043f\u043a\u0443 \u043c\u0435\u043d\u044e \u043d\u0430 \u0432\u0430\u0448\u043e\u043c\u0443 \u0441\u043c\u0430\u0440\u0442\u0444\u043e\u043d\u0456, \u044f\u043a\u0449\u043e \u0442\u0430\u043a\u0430 \u0454. \u0410\u0431\u043e \u0436 \u043d\u0430 \u0456\u043a\u043e\u043d\u0446\u0456 \u0437\u0432\u0435\u0440\u0445\u0443 \u0441\u043f\u0440\u0430\u0432\u0430 %icon.</small>",
        },
        zh_cn: {
            ios: "\u5982\u8981\u628a\u5e94\u7528\u7a0b\u5e8f\u52a0\u81f3\u4e3b\u5c4f\u5e55,\u8bf7\u70b9\u51fb%icon, \u7136\u540e<strong>\u6dfb\u52a0\u5230\u4e3b\u5c4f\u5e55</strong>",
            android:
                "To add this web app to the home screen open the browser option menu and tap on <strong>Add to homescreen</strong>. <small>The menu can be accessed by pressing the menu hardware button if your device has one, or by tapping the top right menu icon %icon.</small>",
        },
        zh_tw: {
            ios: "\u5982\u8981\u628a\u61c9\u7528\u7a0b\u5f0f\u52a0\u81f3\u4e3b\u5c4f\u5e55, \u8acb\u9ede\u64ca%icon, \u7136\u5f8c<strong>\u52a0\u81f3\u4e3b\u5c4f\u5e55</strong>.",
            android:
                "To add this web app to the home screen open the browser option menu and tap on <strong>Add to homescreen</strong>. <small>The menu can be accessed by pressing the menu hardware button if your device has one, or by tapping the top right menu icon %icon.</small>",
        },
    };
    for (var p in n.intl) n.intl[p.substr(0, 2)] = n.intl[p];
    n.defaults = {
        appID: "org.cubiq.addtohome",
        fontSize: 15,
        debug: !1,
        logging: !1,
        modal: !1,
        mandatory: !1,
        autostart: !0,
        skipFirstVisit: !1,
        startDelay: 1,
        lifespan: 15,
        displayPace: 1440,
        maxDisplayCount: 0,
        icon: !0,
        message: "",
        validLocation: [],
        onInit: null,
        onShow: null,
        onRemove: null,
        onAdd: null,
        onPrivate: null,
        privateModeOverride: !1,
        detectHomescreen: !1,
    };
    var c = e.navigator.userAgent,
        m = e.navigator;
    o(n, {
        hasToken: "#ath" == t.location.hash || d.test(t.location.href) || h.test(t.location.search),
        isRetina: e.devicePixelRatio && e.devicePixelRatio > 1,
        isIDevice: /iphone|ipod|ipad/i.test(c),
        isMobileChrome: c.indexOf("Android") > -1 && /Chrome\/[.0-9]*/.test(c) && -1 == c.indexOf("Version"),
        isMobileIE: c.indexOf("Windows Phone") > -1,
        language: (m.language && m.language.toLowerCase().replace("-", "_")) || "",
    }),
        (n.language = n.language && n.language in n.intl ? n.language : "en_us"),
        (n.isMobileSafari = n.isIDevice && c.indexOf("Safari") > -1 && c.indexOf("CriOS") < 0),
        (n.OS = n.isIDevice ? "ios" : n.isMobileChrome ? "android" : n.isMobileIE ? "windows" : "unsupported"),
        (n.OSVersion = c.match(/(OS|Android) (\d+[_\.]\d+)/)),
        (n.OSVersion = n.OSVersion && n.OSVersion[2] ? +n.OSVersion[2].replace("_", ".") : 0),
        (n.isStandalone = "standalone" in e.navigator && e.navigator.standalone),
        (n.isTablet = (n.isMobileSafari && c.indexOf("iPad") > -1) || (n.isMobileChrome && c.indexOf("Mobile") < 0)),
        (n.isCompatible = (n.isMobileSafari && n.OSVersion >= 6) || n.isMobileChrome);
    var u = { lastDisplayTime: 0, returningVisitor: !1, displayCount: 0, optedout: !1, added: !1 };
    (n.removeSession = function (e) {
        try {
            if (!localStorage) throw new Error("localStorage is not defined");
            localStorage.removeItem(e || n.defaults.appID);
        } catch (t) {}
    }),
        (n.doLog = function (e) {
            this.options.logging && console.log(e);
        }),
        (n.Class = function (i) {
            if (((this.doLog = n.doLog), (this.options = o({}, n.defaults)), o(this.options, i), this.options && this.options.debug && "undefined" == typeof this.options.logging && (this.options.logging = !0), a)) {
                if (
                    ((this.options.mandatory = this.options.mandatory && ("standalone" in e.navigator || this.options.debug)),
                    (this.options.modal = this.options.modal || this.options.mandatory),
                    this.options.mandatory && (this.options.startDelay = -0.5),
                    (this.options.detectHomescreen = this.options.detectHomescreen === !0 ? "hash" : this.options.detectHomescreen),
                    this.options.debug && ((n.isCompatible = !0), (n.OS = "string" == typeof this.options.debug ? this.options.debug : "unsupported" == n.OS ? "android" : n.OS), (n.OSVersion = "ios" == n.OS ? "8" : "4")),
                    (this.container = t.body),
                    (this.session = this.getItem(this.options.appID)),
                    (this.session = this.session ? JSON.parse(this.session) : void 0),
                    !n.hasToken || (n.isCompatible && this.session) || ((n.hasToken = !1), s()),
                    !n.isCompatible)
                )
                    return void this.doLog("Add to homescreen: not displaying callout because device not supported");
                this.session = this.session || u;
                try {
                    if (!localStorage) throw new Error("localStorage is not defined");
                    localStorage.setItem(this.options.appID, JSON.stringify(this.session)), (n.hasLocalStorage = !0);
                } catch (r) {
                    (n.hasLocalStorage = !1), this.options.onPrivate && this.options.onPrivate.call(this);
                }
                for (var l = !this.options.validLocation.length, d = this.options.validLocation.length; d--; )
                    if (this.options.validLocation[d].test(t.location.href)) {
                        l = !0;
                        break;
                    }
                if ((this.getItem("addToHome") && this.optOut(), this.session.optedout)) return void this.doLog("Add to homescreen: not displaying callout because user opted out");
                if (this.session.added) return void this.doLog("Add to homescreen: not displaying callout because already added to the homescreen");
                if (!l) return void this.doLog("Add to homescreen: not displaying callout because not a valid location");
                if (n.isStandalone)
                    return (
                        this.session.added || ((this.session.added = !0), this.updateSession(), this.options.onAdd && n.hasLocalStorage && this.options.onAdd.call(this)),
                        void this.doLog("Add to homescreen: not displaying callout because in standalone mode")
                    );
                if (this.options.detectHomescreen) {
                    if (n.hasToken)
                        return (
                            s(),
                            this.session.added || ((this.session.added = !0), this.updateSession(), this.options.onAdd && n.hasLocalStorage && this.options.onAdd.call(this)),
                            void this.doLog("Add to homescreen: not displaying callout because URL has token, so we are likely coming from homescreen")
                        );
                    "hash" == this.options.detectHomescreen
                        ? history.replaceState("", e.document.title, t.location.href + "#ath")
                        : "smartURL" == this.options.detectHomescreen
                        ? history.replaceState("", e.document.title, t.location.href.replace(/(\/)?$/, "/ath$1"))
                        : history.replaceState("", e.document.title, t.location.href + (t.location.search ? "&" : "?") + "ath=");
                }
                if (!this.session.returningVisitor && ((this.session.returningVisitor = !0), this.updateSession(), this.options.skipFirstVisit))
                    return void this.doLog("Add to homescreen: not displaying callout because skipping first visit");
                if (!this.options.privateModeOverride && !n.hasLocalStorage) return void this.doLog("Add to homescreen: not displaying callout because browser is in private mode");
                (this.ready = !0), this.options.onInit && this.options.onInit.call(this), this.options.autostart && (this.doLog("Add to homescreen: autostart displaying callout"), this.show());
            }
        }),
        (n.Class.prototype = {
            events: {
                load: "_delayedShow",
                error: "_delayedShow",
                orientationchange: "resize",
                resize: "resize",
                scroll: "resize",
                click: "remove",
                touchmove: "_preventDefault",
                transitionend: "_removeElements",
                webkitTransitionEnd: "_removeElements",
                MSTransitionEnd: "_removeElements",
            },
            handleEvent: function (e) {
                console.log(e.type);
                var t = this.events[e.type];
                t && this[t](e);
            },
            show: function (i) {
                if (this.options.autostart && !r) return void setTimeout(this.show.bind(this), 50);
                if (this.shown) return void this.doLog("Add to homescreen: not displaying callout because already shown on screen");
                var o = Date.now(),
                    s = this.session.lastDisplayTime;
                if (i !== !0) {
                    if (!this.ready) return void this.doLog("Add to homescreen: not displaying callout because not ready");
                    if (o - s < 6e4 * this.options.displayPace) return void this.doLog("Add to homescreen: not displaying callout because displayed recently");
                    if (this.options.maxDisplayCount && this.session.displayCount >= this.options.maxDisplayCount) return void this.doLog("Add to homescreen: not displaying callout because displayed too many times already");
                }
                (this.shown = !0),
                    (this.session.lastDisplayTime = o),
                    this.session.displayCount++,
                    this.updateSession(),
                    this.applicationIcon ||
                        (this.applicationIcon = t.querySelector(
                            "ios" == n.OS
                                ? 'head link[rel^=apple-touch-icon][sizes="152x152"],head link[rel^=apple-touch-icon][sizes="144x144"],head link[rel^=apple-touch-icon][sizes="120x120"],head link[rel^=apple-touch-icon][sizes="114x114"],head link[rel^=apple-touch-icon]'
                                : 'head link[rel^="shortcut icon"][sizes="196x196"],head link[rel^=apple-touch-icon]'
                        ));
                var a = "";
                "object" == typeof this.options.message && n.language in this.options.message
                    ? (a = this.options.message[n.language][n.OS])
                    : "object" == typeof this.options.message && n.OS in this.options.message
                    ? (a = this.options.message[n.OS])
                    : this.options.message in n.intl
                    ? (a = n.intl[this.options.message][n.OS])
                    : "" !== this.options.message
                    ? (a = this.options.message)
                    : n.OS in n.intl[n.language] && (a = n.intl[n.language][n.OS]),
                    (a =
                        "<p>" +
                        a.replace(/%icon(?:\[([^\]]+)\])?/gi, function (e, t) {
                            return '<span class="ath-action-icon">' + (t ? t : "icon") + "</span>";
                        }) +
                        "</p>"),
                    (this.viewport = t.createElement("div")),
                    (this.viewport.className = "ath-viewport"),
                    this.options.modal && (this.viewport.className += " ath-modal"),
                    this.options.mandatory && (this.viewport.className += " ath-mandatory"),
                    (this.viewport.style.position = "absolute"),
                    (this.element = t.createElement("div")),
                    (this.element.className = "ath-container ath-" + n.OS + " ath-" + n.OS + " v" + (parseInt(n.OSVersion) || "") + " ath-" + (n.isTablet ? "tablet" : "phone")),
                    (this.element.style.cssText =
                        "-webkit-transition-property:-webkit-transform,opacity;-webkit-transition-duration:0s;-webkit-transition-timing-function:ease-out;transition-property:transform,opacity;transition-duration:0s;transition-timing-function:ease-out;"),
                    (this.element.style.webkitTransform = "translate3d(0,-" + e.innerHeight + "px,0)"),
                    (this.element.style.transform = "translate3d(0,-" + e.innerHeight + "px,0)"),
                    this.options.icon &&
                        this.applicationIcon &&
                        ((this.element.className += " ath-icon"),
                        (this.img = t.createElement("img")),
                        (this.img.className = "ath-application-icon"),
                        this.img.addEventListener("load", this, !1),
                        this.img.addEventListener("error", this, !1),
                        (this.img.src = this.applicationIcon.href),
                        this.element.appendChild(this.img)),
                    (this.element.innerHTML += a);
                var l = t.createElement("div");
                l.className = "ath-buttons-container";
                var d = t.createElement("p");
                (d.className = "ath-button-close"), (d.innerHTML += i18n.pwa_btn_dont_show_again), d.addEventListener("click", this, !0);
                var h = t.createElement("p");
                (h.className = "ath-button-later"),
                    (h.innerHTML += i18n.pwa_btn_maybe_later),
                    h.addEventListener("click", this, !0),
                    l.appendChild(d),
                    l.appendChild(h),
                    this.element.appendChild(l),
                    (this.viewport.style.left = "-99999em"),
                    this.viewport.appendChild(this.element),
                    this.container.appendChild(this.viewport),
                    this.img ? this.doLog("Add to homescreen: not displaying callout because waiting for img to load") : this._delayedShow();
            },
            _delayedShow: function () {
                setTimeout(this._show.bind(this), 1e3 * this.options.startDelay + 500);
            },
            _show: function () {
                var i = this;
                this.updateViewport(),
                    e.addEventListener("resize", this, !1),
                    e.addEventListener("scroll", this, !1),
                    e.addEventListener("orientationchange", this, !1),
                    this.options.modal && t.addEventListener("touchmove", this, !0),
                    this.options.mandatory || setTimeout(function () {}, 1e3),
                    setTimeout(function () {
                        (i.element.style.webkitTransitionDuration = "1.2s"), (i.element.style.transitionDuration = "1.2s"), (i.element.style.webkitTransform = "translate3d(0,0,0)"), (i.element.style.transform = "translate3d(0,0,0)");
                    }, 0),
                    this.options.lifespan && (this.removeTimer = setTimeout(this.remove.bind(this), 1e3 * this.options.lifespan)),
                    this.options.onShow && this.options.onShow.call(this);
            },
            remove: function (i) {
                clearTimeout(this.removeTimer),
                    this.img && (this.img.removeEventListener("load", this, !1), this.img.removeEventListener("error", this, !1)),
                    e.removeEventListener("resize", this, !1),
                    e.removeEventListener("scroll", this, !1),
                    e.removeEventListener("orientationchange", this, !1),
                    t.removeEventListener("touchmove", this, !0),
                    this.element.addEventListener("transitionend", this, !1),
                    this.element.addEventListener("webkitTransitionEnd", this, !1),
                    this.element.addEventListener("MSTransitionEnd", this, !1),
                    (this.element.style.webkitTransitionDuration = "0.3s"),
                    (this.element.style.opacity = "0"),
                    "ath-button-close" === $(i.target).attr("class") ? (this.session.lastDisplayTime = Date.now() + 6048e6) : "ath-button-later" === $(i.target).attr("class") && (this.session.lastDisplayTime = Date.now() + 36e5),
                    this.updateSession();
            },
            _removeElements: function () {
                this.element.removeEventListener("transitionend", this, !1),
                    this.element.removeEventListener("webkitTransitionEnd", this, !1),
                    this.element.removeEventListener("MSTransitionEnd", this, !1),
                    this.container.removeChild(this.viewport),
                    (this.shown = !1),
                    this.options.onRemove && this.options.onRemove.call(this);
            },
            updateViewport: function () {
                if (this.shown) {
                    (this.viewport.style.width = e.innerWidth + "px"), (this.viewport.style.height = e.innerHeight + "px"), (this.viewport.style.left = e.scrollX + "px"), (this.viewport.style.top = e.scrollY + "px");
                    var i = t.documentElement.clientWidth;
                    this.orientation = i > t.documentElement.clientHeight ? "landscape" : "portrait";
                    var o = "ios" == n.OS ? ("portrait" == this.orientation ? screen.width : screen.height) : screen.width;
                    (this.scale = screen.width > i ? 1 : o / e.innerWidth), (this.element.style.fontSize = this.options.fontSize / this.scale + "px");
                }
            },
            resize: function () {
                clearTimeout(this.resizeTimer), (this.resizeTimer = setTimeout(this.updateViewport.bind(this), 100));
            },
            updateSession: function () {
                n.hasLocalStorage !== !1 && localStorage && localStorage.setItem(this.options.appID, JSON.stringify(this.session));
            },
            clearSession: function () {
                (this.session = u), this.updateSession();
            },
            getItem: function (e) {
                try {
                    if (!localStorage) throw new Error("localStorage is not defined");
                    return localStorage.getItem(e);
                } catch (t) {
                    n.hasLocalStorage = !1;
                }
            },
            optOut: function () {
                (this.session.optedout = !0), this.updateSession();
            },
            optIn: function () {
                (this.session.optedout = !1), this.updateSession();
            },
            clearDisplayCount: function () {
                (this.session.displayCount = 0), this.updateSession();
            },
            _preventDefault: function (e) {
                e.preventDefault(), e.stopPropagation();
            },
        }),
        (e.addToHomescreen = n);
})(window, document);
