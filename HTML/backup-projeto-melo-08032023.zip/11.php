<!DOCTYPE html>

<html>

  <head>

    <meta charset="utf-8" />

    <meta name="viewport" content="initial-scale=1, width=device-width" />



    <link rel="stylesheet" href="./11.css" />

    <link rel="stylesheet" href="./11_b.css" />

    <link

      rel="stylesheet"

      href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap"

    />

  </head>

  <body>

    <div class="profile-chef-melo-viso-do">

      <div class="profile-chef-melo-viso-do-child"></div>

      <div class="profile-chef-melo-viso-do-item"></div>

      <div class="chef-melo">Chef_melo</div>

      <div class="collections-available">10 collections available.</div>

      <div class="nice-to-see-you-here-user-nam">

        Nice to see you here, user_name!

      </div>

      <div class="did-you-get-the-page-of-my-new">

        <span class="did-you-get"

          >Did you get the page of my newest collection, </span

        ><span>name_collection</span

        ><span class="did-you-get"

          >? Tap the button to get the page and start collecting today.</span

        >

      </div>

      <div class="collections">Collections</div>

      <div class="page-1">Page 1</div>

      <img

        class="profile-chef-melo-viso-do-inner"

        alt=""

        src="public/rectangle-23@2x.png"

      /><img

        class="rectangle-icon"

        alt=""

        src="https://d1xzdqg8s8ggsr.cloudfront.net/63acdfd633a79ad2d31d7775/9aea7a88-cd16-45fb-8894-05e5ef30eef3_1672273888035334826?Expires=-62135596800&Signature=UrPjyFXITttyQ08u5efWBu395l7aBYg83PCtdssqaFng0YzvGemQLTzYVLD34m-TO8Yi862dulRAwE7NPBu5D4P7lvkIpHfYW32JdoUiqnmuc0srom6ISFGhXkKKHeMRe~O9Kgzb59JTRv9T~83lMyJBOmzEPaQb~oHPY7oGZp64d9UQzwSpDvpE0fIl3Y9ALpSMtVgQN2LybVGgIlLDFkHd583qZ151poKfCE6f837h~zTB-fCrjyIy1rQVl8ipGHYt-4nVlJlJQMzlDoOmHdPZdLq~osAElXDWFtujkeqUyru1YozPBs7NNGnNLZEabhgnlmx2QvOIuy~lLY0Atw__&Key-Pair-Id=K1P54FZWCHCL6J"

      /><img

        class="profile-chef-melo-viso-do-child1"

        alt=""

        src="https://d1xzdqg8s8ggsr.cloudfront.net/63acdfd633a79ad2d31d7775/ca6b058e-ebaf-4dfc-9746-2d4cc66b558a_1672273888035437358?Expires=-62135596800&Signature=wCY7hORp70I9M9geUA71-8x6dJ6C7AVnR3dt090s2oedcQZ15RuAT7Qd5LyxkdbH~yaitr92j3m6ZyaTRyI6plxOLzsvsJUy7K07IKBLmmClT0M0p~NnimitJM8TTRuAWBCVTZ9gLY4MBXZe6a8omTW8vByOhxDxK6SIae4XCa-yKhJu8pc2vR9YipEg8-iqhHyXGRimF9sDiePejn73mqXxFdnSVlIL~lsZDegflwvoMvsBr7NSBap7qQrv52~qMFhgQUreZTc-CxXhPi5pN8dwVhhS~YuDcRrGslJRJ0Kh52F0ydjtKlhnYXiwuw4cTPKDQznVCzb6jeteNJxHOQ__&Key-Pair-Id=K1P54FZWCHCL6J"

      /><img

        class="profile-chef-melo-viso-do-child2"

        alt=""

        src="https://d1xzdqg8s8ggsr.cloudfront.net/63acdfd633a79ad2d31d7775/edd27c51-0623-44fd-ab68-3b7fc5d0ccf2_1672273888035529358?Expires=-62135596800&Signature=ePFPOpNsvSAjDmkzb7kBrMQ1BkKhWzljfQiSekcUCFi~rmDxDDGbEJt4KaKF-QN2MLJoLktClyTJyVfFqIpHhBAj3xw0WnFhLSsJ8NVklmDALIHGjbbec5x6s~evFJb7A6oSqXjiU~fVBYT-avSBkJQmjuqCuSVuPOV~aBmdVubz0vjv7Kw1c13ewzgnrRWwlt93jO-cVBZWDZuuUAo-rGno0Bs~vd4B~2CqBAncVVifdftvA5dyXGNnHPW8kXJLRlw4xB-lTpqiVp~LZ19dzp~4CGx6maAtlivayjbbRdt7s-ak4ee1IvECMW7j4xc2LR3Ax7i7FGEfYTSSkn2fIA__&Key-Pair-Id=K1P54FZWCHCL6J"

      /><img

        class="profile-chef-melo-viso-do-child3"

        alt=""

        src="https://d1xzdqg8s8ggsr.cloudfront.net/63acdfd633a79ad2d31d7775/63006942-b49a-4f87-9c77-9651ca3ae762_1672273888035616960?Expires=-62135596800&Signature=AFc-6PTJIPtZ8BAQy39HdPzDdJk7cwwJh378pxQL6H-4yBKsiYm1c4SgL7m2vDHKoKYPQ~g7wkIZ-9QNDxZWpNOEGeWlhQ6gQQqCkiXv3JnHdbnxUIuBZdFS34qH~cygMB1-fYP-ybYWLX4eSO1~0Y9l4HEy3U2EwYhukNXzw0a2n0Tnq-LyIuiUXvWWNg0aRJ1BfNiwMJsWGyEyNHvQj9p3sB7oxHjvCqzMIB9AzEdhsG3b6B66AUXyVO6nNmwnIW5GC~tnANU6SO0s~IElO0IMm-N9AFxr4tVLdInS0ZAxmgjjgBtLrIC32XRXiN5vtYoa08EYezhVqyrsgmT-yA__&Key-Pair-Id=K1P54FZWCHCL6J"

      /><img

        class="profile-chef-melo-viso-do-child4"

        alt=""

        src="https://d1xzdqg8s8ggsr.cloudfront.net/63acdfd633a79ad2d31d7775/9d8ac281-322a-47b5-905a-d79369594f1f_1672273888035708038?Expires=-62135596800&Signature=mXEj8n0qKyf4jtKamKb4-l6aDGOL07FB5QuU6kG4skbs~zchvpLuz29FVUz-YkSXhcQCuigmjljKTMa6X-tWnJ5Uhgwt9gv4XEv1-vdfeIMtV8BJRmmHsSD4Xni1yJcpJkOxrzlzaDpVtKtBV2wvNkrynDdMUKZThRSduOm3Lzmd9FZOU~afhIu2sHvns3-zBoCUPDEoW0NExT~NBs~-6nT2XZK6iwtdu49XGSiDYRe7o-vhIWSzeQKrKpqMDDfpSonVFMwHyyknz0sWPhgloCqiSxl7-xqRfs69w6rVeway1IGUDJMg7tMoQGiaZ5YtOVPWVkAkgNVlJ9ayQ-SwOQ__&Key-Pair-Id=K1P54FZWCHCL6J"

      /><img

        class="profile-chef-melo-viso-do-child5"

        alt=""

        src="https://d1xzdqg8s8ggsr.cloudfront.net/63acdfd633a79ad2d31d7775/853d7ea0-3e9f-4a9b-8d1d-0e3fc5ce959b_1672273888035795339?Expires=-62135596800&Signature=dVgOmOZRObPpYYZgJRb47fy4xxYPdaOw~rE3iICLJrCu5wlNQW5bl6SVpIR819Xj~5BB2YVfxs5BntY3yAGKVh2CLnVfKyJVMSlNk0pfQzCX9AQwM3Kf07cpnCoH8-u~WgfVnyRibVtPvu6KfPlFIzYXVyaVlFqhy2osRiDq0FSDoMtQiOahbkncrymJ80WmKbY1MuyYu-dTe97UCtvci6ZI~DqDr2L5g3tnfSJhAQurOwIwjDpq~zQHo6mj6uWhbXm~wODwpnQrU9Nc6J2F8pvtkKLLnCodgLDDN39tlnIZ57j8W9OS9z8QKPjTjpJC4hlMgfnesJ8waZXdB56yUg__&Key-Pair-Id=K1P54FZWCHCL6J"

      /><img class="ellipse-icon" alt="" src="https://d1xzdqg8s8ggsr.cloudfront.net/63acdfd633a79ad2d31d7775/a79ff5f0-7c79-4323-a643-e5efc0158608_1672273888035882373?Expires=-62135596800&Signature=KSrDmkCQ-G~U7K39fIYR-33IeqxF2NwraVgyjn-iu0DbA~re5MO327qMpcu~YBrV3gCJP6hpDIm0D1K5kdl~m3GBOZA9Lc-14JjqFJFh3C4kMpXG4O8CDaANEF-1FAgUHTWDcrBqPmzhtj7rncySZKU1akjvbqbQ6mquggSyK-gRvg77OFJAD3~C4iKoPqx6s~MPeyILy8GDXRmnVhVgB9D5O1jnfzEEY9uJy9-UneKq2I75pDvVQuflKrJ55JOIoiskT4d1TB4mGO8t0h9XbwZqdYmFwLOu7y190EA14ZgGMEaEL9c-16bwAihWo6nMdzKwIvlT8NGiMa-FhpBVTQ__&Key-Pair-Id=K1P54FZWCHCL6J" /><b

        class="get-this-page"

        >GET THIS PAGE</b

      >

      <div class="fixed-itens-bg-superior"></div>

      <div class="search-bar">

        <div class="barra-de-pesquisa"></div>

        <div class="search">Search</div>

        <img class="icon-search" alt="" src="https://d1xzdqg8s8ggsr.cloudfront.net/63acdfd633a79ad2d31d7775/91f8c166-dc53-4f9b-a960-00c8b488bfca_1672273888035969816?Expires=-62135596800&Signature=DNRZ4mjrGDv3z~5Ei0jdkp6cbEjVE~hQXluWiIyZDcdrq58XA7FA4MI7oRUsg3fJCwQAKQmZGuF9JL2VDn7LY66aKUPWOKifM0yCOyM4UKMv8hEdOHuMnHvTpupZrWWgG9PbgBdfPjYHIKDfmSnZAxUxAtjCbnPVnY9dTC33bvqn~d47cdXzUIKqnxVBmbvwoZYAN1syYLyKFAdXKFPHzjxLYP3GG7D72DmRuYy9Df1ursCwNgDARdnl8mN9MbLMNnnXJo7Hr9iZPTz4cw~m-T0LOPRjxOKvc0lJ1c9cLj0GR3thotUSGWakocJTWlvepThWwRNtQOtRuWN4tP-jFw__&Key-Pair-Id=K1P54FZWCHCL6J" />

      </div>

      <img class="icon-side-menu" alt="" src="https://d1xzdqg8s8ggsr.cloudfront.net/63adaa2b2434a4e554746687/f8491da2-3b82-44fa-a12c-507e834c5db5_1672325708144518547?Expires=-62135596800&Signature=Gtn31AYH2D5zFfIIhObRPjBuVQsKP3E3g28JSXbKCi0GIMby6cgbggHGBk-UPdDcyTS6eLyOtBAD5LLLVXzCcpJEabt5UrZbDVYb3V4z16RlwrAiFTtlVw5BJjPjjDC4ukkSZwUZTltYbS7Tt1d9Ovpz2JDR8H0hA4~6s8BPgB93kr0A1WOP-glcKYz6nXY6xXwKTovEbc~Vz3NiwmYPLHWvXRpzBiTRJPTvTNXKnaK9GMZzLAjSKPPS2kbZr4spgLYXZc9wLJlWe0hfo-Y2xOpJJ0HkjffsKJo-mSQ0iy4Kutuq4ywgRd4ZB~UPStsKxexF53~D6mwhWDe4nv5s1g__&Key-Pair-Id=K1P54FZWCHCL6J" />

      <div class="rectangle-parent">

        <img class="group-child" alt="" src="https://d1xzdqg8s8ggsr.cloudfront.net/63acdfd633a79ad2d31d7775/07cd7960-0be3-4b4c-b6c7-07861c31b52c_1672273888036139497?Expires=-62135596800&Signature=TRAp86CGgDH7uzFSIpdnCfDn0rbQdhSZ6tT~PST1YL8v2iP5jbicwQ4TXHp9Qhf7FHJ2Jan~uov8A5lfCY8qdFnw7W85LkUitdSkb2PooHxCyGQeg-lN8LEcvLdYu~lVL2GmbEzgsFjRNT7cPeR6~mvXBVXL450jipduWu4JL1pHQIxcqtIEgKKTvkxgMey11OLRo6r-dOFSp6x4LSXo7LXFS5xED7rtEWRvcM0r5DcHTRPjmBPJbtSjF3uRrhwadI6t~6sQVjFxhKY-sRXdLbqYuG54yOt4Qr2waF-IevVN6FRcK0bwtRJWUGD69eZSGAu2AyNKPa7EnbszJH78ZQ__&Key-Pair-Id=K1P54FZWCHCL6J" />

        <div class="my-collectibles">My Collectibles</div>

      </div>

      <img class="menu-icon" alt="" src="https://d1xzdqg8s8ggsr.cloudfront.net/63acdfd633a79ad2d31d7775/da94e0c2-0219-4884-a4d1-b25626aad282_1672273888036224308?Expires=-62135596800&Signature=oOJ0dXV~QbyXqUmRKNZEV2DQOxtlLCtWqiDsdE5SGhi7rKozCuIed9Le5a-mc2BmVNiKGw5ppJGUMSbvjmuveKGnnYJAF5Wl76LBB6AOMPah~81~qLs5glSSj1~TU5OAWOFB3SWU~fLvHAF7msyAztF1ReoZZuIraH1~RkddgUQIC7QmZmtS3lyfYh3e-f4AsY1PYUh4QUAma3CUxFF8u-koDJoDnztIyjjF3Oji4YEearfxqKwHpMySkCebCkI8mJoskL9kAUciGI1dZh0cMmTtZsQ4rc7atE4glCAZbFyGzI0qhRZI9E1dVtkSMSrSzHgir8qdAxGn7-sJZWvk~w__&Key-Pair-Id=K1P54FZWCHCL6J" />

      <div class="a-delightful-christmas">A delightful Christmas</div>

      <img

        class="profile-chef-melo-viso-do-child6"

        alt=""

        src="https://d1xzdqg8s8ggsr.cloudfront.net/63acdfd633a79ad2d31d7775/a120c7c2-f7ff-4ffa-a323-8740fe41db18_1672273888036312615?Expires=-62135596800&Signature=drdkmoj-3rsK-Xz9Iw70jjKWEBPZWUv8MriOlEp6~vXdzPNsHw3dHQC6Ohz5RUM8Ow4D1YBkKM3q1vVJv2nXNeh6COWKg-beMxJ2IMbfE60iNwhA4mucusm2XosOqYSCcQlEhVpR-0VI-M0oDB7ECgHuiQh5maYkb8Kd33ozyg-aL~lMLodxD3GX6WycGrsZh5wIEyFOrmHD~L6pdRINpmGDiXNtQ4hObADG-GNUbqHhpI6KsCX6tJatGQaCHsNcG6cRVQORj2BGq27zcpa2hV4K-rSG1sVte4LDkAKWvkn9vscIbypFWnoJPDUq2jSooarv4sG8BXKJLBPmyuD6ug__&Key-Pair-Id=K1P54FZWCHCL6J"

      /><img

        class="profile-chef-melo-viso-do-child7"

        alt=""

        src="https://d1xzdqg8s8ggsr.cloudfront.net/63acdfd633a79ad2d31d7775/d7e1bf31-53d8-4af1-9142-74b6b401dd5b_1672273888036395633?Expires=-62135596800&Signature=rdCgU7VxvDxtHxTn~Dpdjmu56j3OgegmleUNvkgGdztYoJxqZOYHLsyFg7G48n1RddkwGNOtWhWOlkspEgd4J8SS52d4kcp0wnh43hnUs4UXXnhsmrIuH3odVyH~n4GgBm2nBVotAXzIC1mYfDczdFcjZ5sBN7nfedrC00vbR1vN9lrhifyd1LYJBo5TylgZMH6Vd7wQ6TgZVlvaAbo~0HWLuGFbe2tSeUtbGBpWlcpc3aQlvDO3eOYO4~7EFaDqHcYo3rONn~qTLCT7azT74JxUL9RDeWI4x~abhzMBgFJvTd0iXHaf9nsq~gEiFbI9MDauo05FmNXHllWtk4rmqg__&Key-Pair-Id=K1P54FZWCHCL6J"

      /><img

        class="profile-chef-melo-viso-do-child8"

        alt=""

        src="https://d1xzdqg8s8ggsr.cloudfront.net/63acdfd633a79ad2d31d7775/58185f44-9fb6-45a2-bd74-38d7f8c34d4b_1672273888036479063?Expires=-62135596800&Signature=HM1Yvp1v2wQcCw-y-gQTk8H~ae-635NtLiN6rrh70-vTBXMPT~HiW8mXKRGKHcBUGrwWsIDIxWXy2ndAuTmJRviMlT5DsDj~GPPzZwpLJ1XJFDawjZ~hcfvYRurWjndHBMEV6jkQdygFQDbVNbJBphmA9jhjWhwHYQgFwUWfe2GLWEeti5Jaxqmx-8Q9uYvqtEhBidDeYRE4HlLP-PgTyzimLFoNwpnbdL7qacunY5ymPCsxyORtAky0fdG85zvmPyOtChlmXyxt-r1D4B6TBUBJW-Kq6kPtD3uX2PsU96j8i8qWVaq39417pfSJlVxxDpVFW2~qJ5KOR8a~MJ66OQ__&Key-Pair-Id=K1P54FZWCHCL6J"

      />

      <div class="icon-home-in-parent">

        <img class="icon-home-in" alt="" src="https://d1xzdqg8s8ggsr.cloudfront.net/63acdfd633a79ad2d31d7775/e11c1173-bea4-425e-b02e-09e0d9d1076d_1672273888036562997?Expires=-62135596800&Signature=k0NZqXU5mipSDjou9qSvVTVuLIMhle-2MMCr0VgIURLSnmUEBiV7H~91YxPi7t9mtAzaYRGLVsGrNwMVI4Azxwff~WRK-p8ZDW12tTC4ZMfOTv5SLZ2ehB66nxTWrZ5cYOaVfM4bj9JH0TpdmYmXRKwBcSWHngE~RHB9zcBCzEUzu0-l2KXWTw6dWYDdgajjG8Svw5tImQ977NSrxs-TmCOO3JzXNM8aJZsW8DP8rhtnCSceDDXXFYJyMEa9d3rtju~3kpsg6hX8YFFxMJJ-6bTHWA4SBkHK-CWl7qBUBlMaiaaOUznuS43SOfbKkxNVFpsSBLTR5xH8HiYNSrnLyQ__&Key-Pair-Id=K1P54FZWCHCL6J" />

        <div class="home">Home</div>

      </div>

      <div class="profile">

        <img

          class="icon-profile-out"

          alt=""

          src="https://d1xzdqg8s8ggsr.cloudfront.net/63acdfd633a79ad2d31d7775/4f4548de-efb1-47b1-a583-ca5940cf6c87_1672273888036647256?Expires=-62135596800&Signature=ND5Z7HN-937w9XeRRqWGIRZvatLlxW-ZEehAO73EP~RpxWCbj79BXwo2W6nhfC5SN7-3N1ieNL4lvLuGqsvEbseWCWH0hYOlTrGvQACN16PFrB~JRBkOuiVRvlJHrQqrr4cs2V2rY~-NALbwnggLsnpKeqm1F5axgFj-l0IdBi9tSMKO2XkUV5luR47gB5t9kXnQqOrbmZKoEon~s657Frp009rKJNLK95GHlkfsLMs9KexuPyT9aniGLU4w9EACXaLnt9C7i9~PIeWdNLmTGXOUbljO62SBj3HURqk6ni0J3IeVm8oTiQVumlb9GxQz960J~kARL0nsIO521XCnZg__&Key-Pair-Id=K1P54FZWCHCL6J"

        />

        <div class="home">Profile</div>

      </div>

      <div class="profile2">

        <img

          class="icon-profile-out1"

          alt=""

          src="https://d1xzdqg8s8ggsr.cloudfront.net/63acdfd633a79ad2d31d7775/5a1d8227-c0e0-4d0a-99a5-e8f12a8f7da6_1672273888036738739?Expires=-62135596800&Signature=jXU4T59~ZSN5OPcXcILBcf-NOmg2pHnoaQTA6ethczoIiC0X3-Qf9RpguEjfzFc4qXE7Z83~XKOdYxZTXRyAJ6nZyKN4YpDtUTYU-9raLXHFMZ9g8oBGBt-B5ZxZIdHDkXf8Ea0bP2KSW72fY9RIvJnNj1ZJLrFv4TsGukKUNgZTPu-QETVUdoUkBrltTS6qpdTMNYJdFPsP1Hj6sAI61fJzvazG8a74cbsK8sxXc8Nw~G-sOhjg~IhWyGSlKcPMefAzIqRhdCdDP4glm-Jfs5ZTbbwGw3Vz8DvWM-GEVqR8~aYASOOpAKHBXAM0TfzhBi598SWKx4CDrlPXTVdNmA__&Key-Pair-Id=K1P54FZWCHCL6J"

        />

        <div class="community">Community</div>

      </div>

    </div>

  </body>

</html>

