<a target="_self" href="<?php echo "https://thechefmelo.com/my_profile.php?token=".$access_token_seting . "&v=".$time;?>">
    <div class="menu_f">
        <img width="27px" height="28px" src="img/Icon-Profile-Out.png" alt="">
        <h2>Profile</h2>
    </div>
</a>
<a target="_self" href="<?php echo "https://thechefmelo.com/home.php?token=".$access_token_seting . "&v=".$time;?>">
    <div class="menu_f">
        <img width="27px" height="28px" src="img/Icon-Home-In.png" alt="">
        <h2><b>Home</b></h2>
    </div>
</a>
<a target="_self" href="<?php echo "https://thechefmelo.com/my_comunnity.php?token=".$access_token_seting . "&v=".$time;?>">
    <div class="menu_f">
        <img width="27px" height="28px" src="img/Icon_community.png" alt="">
        <h2>Community</h2>
    </div>
</a>