<!DOCTYPE html>

<html>

  <head>

    <meta charset="utf-8" />

    <meta name="viewport" content="initial-scale=1, width=device-width" />



    <link rel="stylesheet" href="./05.css" />

    <link rel="stylesheet" href="./05_b.css" />

    <link

      rel="stylesheet"

      href="https://fonts.googleapis.com/css2?family=Inter:wght@300;500&display=swap"

    />

  </head>

  <body>

    <div class="chats-chat">

      <div class="chats-chat-child"></div>

      <div class="user-name1">user_name1</div>

      <img class="chats-chat-item" alt="" src="https://d1xzdqg8s8ggsr.cloudfront.net/63af30fae1a35901d59e1d0e/d3f390d4-81e0-4a30-8e52-174bce36e73f_1672425745498806716?Expires=-62135596800&Signature=Gdarg-dBzOc1~oL9zydx6X7bYL5rT~m2K22g2sI1rh-U-6wvoQW3jYnMx~El-j8shYLKa0MtzlgChuXfKnX7TDNE8yQX5gsFjGWTL3xRmB9RYeRiERLHc~p0OeZ8fpICWuvQTZhJUszs7zgLQKy8gYh397r3d2n5c5Qf8T9G0Xmx6O3I2DoN9LkFZqS6TfeOB9XG6Xh7ogjMb-7f8-nFb1l4f0tM77Au3AmoU5btdAbLT~A8-geUq9iCXsT9dJLG5MKLuWmYNDCYKjFLI75SNOOZz96n~7udCqqYfmg012elmDbmdCCwuNACjFkczMXFNE5heey0c5Bx8~7bNP9fbg__&Key-Pair-Id=K1P54FZWCHCL6J" />

      <div class="chats-chat-inner"></div>

      <div class="tap-here-to-write-your-message">

        Tap here to write your message...

      </div>

      <img class="ellipse-icon" alt="" src="https://d1xzdqg8s8ggsr.cloudfront.net/63af30fae1a35901d59e1d0e/8f6e70bf-0761-4f7a-80bf-dc915239c27f_1672425745498994636?Expires=-62135596800&Signature=UfWj4QZx1s22pkRICMRX18QCiXGav3XAHQA8MbBaoqIolGXKuQeOv3Y1NmIeJtBMDnSOsPzIZFoduRLqUzkCejetify6JapXEfuRlxutVKp2ty8Gd~caCSTcjKeyEqcdBB-tSsEzpf6D-y66Gny1PurCcVQZi0CXf304aXX-m~FPL~f49KgZ1dI72DjIAGhqZlhCAXTP6eWt2gllJhmqwsNvdyG2AHtkDEQknlXqVrgCq11-CW-PKDbvvQSStGNIOYfjk1gHZ7WarGvQP-kIAXAGJoMdyCaNNb3ndsQ7~4vvlHn3jvsHRrtlFPhOzYX9u89G7UaZiaGxqb9ps8EmhA__&Key-Pair-Id=K1P54FZWCHCL6J" />

      <div class="rectangle-div"></div>

      <div class="chats-chat-child1"></div>

      <div class="lorem-ipsum-dolor-sit-amet-co">

        <p class="lorem-ipsum-dolor">

          Lorem ipsum dolor sit amet, consectetur adipiscing elit.

        </p>

        <p class="lorem-ipsum-dolor">&nbsp;</p>

        <p class="lorem-ipsum-dolor">

          Sed neque erat, scelerisque eget tincidunt nec, venenatis eu neque.

        </p>

        <p class="lorem-ipsum-dolor">&nbsp;</p>

        <p class="lorem-ipsum-dolor">

          Aenean dignissim mi eget velit vulputate imperdiet. Donec et nunc nec

          felis scelerisque egestas eget sed urna. Nulla facilisi.

        </p>

        <p class="lorem-ipsum-dolor">&nbsp;</p>

        <p class="nam-venenatis-fringilla">Nam venenatis fringilla odio sed.</p>

      </div>

      <div class="lorem-ipsum-dolor-sit-amet-co1">

        <p class="lorem-ipsum-dolor">

          Lorem ipsum dolor sit amet, consectetur adipiscing elit.

        </p>

        <p class="lorem-ipsum-dolor">&nbsp;</p>

        <p class="lorem-ipsum-dolor">

          Sed neque erat, scelerisque eget tincidunt nec, venenatis eu neque.

        </p>

        <p class="lorem-ipsum-dolor">&nbsp;</p>

        <p class="lorem-ipsum-dolor">

          Aenean dignissim mi eget velit vulputate imperdiet. Donec et nunc nec

          felis scelerisque egestas eget sed urna. Nulla facilisi.

        </p>

        <p class="lorem-ipsum-dolor">&nbsp;</p>

        <p class="nam-venenatis-fringilla">Nam venenatis fringilla odio sed.</p>

      </div>

      <img class="polygon-icon" alt="" src="https://d1xzdqg8s8ggsr.cloudfront.net/63af30fae1a35901d59e1d0e/1062dbfc-f27d-46c3-bb27-02e6b7e9136b_1672425745499103135?Expires=-62135596800&Signature=UKQeNtd1pBWBjSmzGewmmRfqbSQBngwvBRSOA9x6miZLGeG1dv9P2751fdAFyV2SH31Do9eWbPAphEzhqspZs91eMlvn~jQcISJ1PLUKwl8bcePWXjQLSL1CPoMpwxJY~7Pi-sYaw83JsQvSfg7ZfEJewg-OhhYkDPQZej6O7v4Z6YvoQqJpBq8E4YwsF0PL9a--X8IjwM7MVLQI8r6R~X33N8znVkyN98trPYUJEqMSVvVzM2bRG4j8tmjc9hxlVadvBG-IuYIOts6YZo~zgZ3UjFuq9ln67eKx2GPLjiLgGohBbTBixWmx71bFgMtsXoiVQGDJQj-cAUVuQqRZQA__&Key-Pair-Id=K1P54FZWCHCL6J" /><img

        class="chats-chat-child2"

        alt=""

        src="https://d1xzdqg8s8ggsr.cloudfront.net/63af30fae1a35901d59e1d0e/cb621448-1ec5-413f-be43-202aa8e55fd6_1672425745499197476?Expires=-62135596800&Signature=pgakgtvhg0TYV6X9ksnc34rzePgjDu9sCpfkFOv4HGisJnCI6A6Swmcp-EkeBevZScvRkGaGiqjAjzXLsZDqx3PuCAaZDZ8ZW-vdgkmq6spFYEzPKw~n4cPkucvh5zCxkU4bgyASKkXa2DK7nS09xnYMgbfOWJfJ7WNE4zwBNrJQ6LYNcVDQ2e-5brnVJkclbiOLNMgvwPPOGB1MzYMiC7~XuAx7YHEHcMvf4249dV54skWST6o5EwgHsUAp4WRhzzFTjYLHfzgcb-~UCXqXab97069RdB-AR8ZhB6ZA01NQt865Cdyx3H604Bo4Y5Ves--dOZ6FyLnyT5tCc2lJPQ__&Key-Pair-Id=K1P54FZWCHCL6J"

      />

      <div class="div">09/08/2022</div>

      <div class="div1">09/08/2022</div>

      <img class="chats-chat-child3" alt="" src="https://d1xzdqg8s8ggsr.cloudfront.net/63af30fae1a35901d59e1d0e/5eedfc73-38f4-4662-9153-775538a32d81_1672425745499287193?Expires=-62135596800&Signature=pbNsUrkmrBNg1mQqqt36ixkL-HZodm8UhAXhS24K6bNMibJot0Xg3NxHBqxCBVsXGRMNmb2HdrPkao~8H-~uCI7oaQe~P4pQPqpVjraupzWKeMSwCLdvq1RH7pqzZEqu3KU3L~huIKrVJYJhgjGOwI3nHx5hEBuGQvyPnlWKTtQ-AxbNwVEDKOwYm5bx2N1SB1Bk6yqbBDOMnzYBxyH8hnIPK8ZVJBHu7IKXIqeBAshiYov-xOkrmXrFraqlZVirLTGhdCNbOqMUD1sK2UG36HAKfL6AGBZklYpZOOnYTO9iKtyW6Vk4ZFkG~tRgxlbDO-iE0bPhSSQKckPBLzBT2w__&Key-Pair-Id=K1P54FZWCHCL6J" />

      <div class="div2">!</div>

    </div>

  </body>

</html>

